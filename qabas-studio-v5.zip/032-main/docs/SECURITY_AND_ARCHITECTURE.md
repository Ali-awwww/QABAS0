# Qabas Studio — Security and Architecture Guardrails

## Authentication

- Release builds require Firebase Authentication. There is no password-length or email-pattern fallback.
- Local demo authentication is available only in `DEBUG` builds when `debug_demo_mode` is explicitly enabled.
- A successful Firebase login is followed by a server-derived role lookup.

## Authorization

- User roles are `USER`, `PREMIUM`, `RELATIVE`, `DEVELOPER`, and `ADMIN`.
- The app prefers Firebase custom claims for privileged roles. The Firestore profile role is only a compatibility fallback.
- Client preferences are UI/session cache only; they must not be treated as a security boundary.
- Firebase Security Rules and/or trusted backend code must enforce privileged operations.

## Payments

- The client no longer generates fake payment intents or treats a `pi_test*` string as proof of payment.
- A production payment flow must use a server-side payment provider integration and verified webhooks/entitlements.

## Local data

- Room no longer uses destructive migration fallback. Add explicit migrations when the schema changes.
- Avoid adding secrets or authorization state to ordinary preferences.

## CI

- Pull requests still compile, but APK artifacts are not uploaded for pull requests.
- Uploaded APK artifacts are retained for 3 days to reduce GitHub Actions storage pressure.
