# Qabas — Round 3 Product Hardening

## Focus
This round treats Qabas as a production product: remove misleading states, separate BYOK from paid entitlement, and make startup/payment behavior reflect real system state.

## Changes
- Removed default virality/confidence values that implied measured AI output when none was available.
- BYOK (a user-supplied Gemini key) no longer grants the paid Pro entitlement automatically.
- Store/Profile premium gating now depends on an actual entitlement or developer/admin role, not the presence of an API key.
- Removed local recharge success paths from the legacy Payment screen. Coin recharge is now explicitly tied to verified Google Play Billing.
- Startup loading no longer advances through fabricated timed progress or a hardcoded 9-second auto-finish.
- Startup cloud sync is conditional on an authenticated Firebase session.
- Startup errors are surfaced as warnings instead of being swallowed silently.
- Operational readiness copy no longer claims 100% readiness or a measured 300ms latency without evidence.

## Verification limitation
Gradle compilation could not be executed in this environment because the Gradle 9.3.1 distribution is not cached and `services.gradle.org` is unreachable. No claim of successful APK compilation is made from this environment.
