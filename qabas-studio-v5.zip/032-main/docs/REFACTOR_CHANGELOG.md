# Qabas Studio — Refactor Pass 1

## Implemented

- Removed the Firebase login bypass and all email-pattern based admin detection.
- Added explicit roles with server-issued Firebase custom claims taking priority.
- Restricted local demo authentication to explicitly enabled debug builds.
- Stopped release navigation from trusting stale `is_logged_in`/admin flags in preferences.
- Separated guest state from authenticated state.
- Removed fake payment-intent generation and `pi_test*` confirmation logic.
- Removed Room destructive migration fallback.
- Added Android Keystore-backed encrypted storage for API/Firebase credentials and migrated legacy plaintext values on first read.
- Stopped persisting raw Firebase JSON in ordinary preferences; it is now encrypted.
- Reduced GitHub Actions artifact pressure: no APK artifacts for pull requests and 3-day retention on uploaded APKs.
- Added security/architecture guardrails documentation.

## Not claimed yet

The project has not been fully compiled in this environment because the Gradle distribution is not cached and outbound access to `services.gradle.org` is unavailable. A GitHub Actions build should be run after upload to verify the complete Android/Gradle dependency graph.
