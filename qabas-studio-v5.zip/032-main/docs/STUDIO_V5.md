# Qabas Studio V5

## Editor model
The studio now treats editing as a persistent, versioned document rather than a transient screen state.

- `StudioDocument` is the canonical local document format.
- Drafts are autosaved to app-private preferences under a project-scoped key.
- Undo/redo keeps up to 50 scene states.
- Scene operations are non-destructive: move, duplicate, delete and metadata/media changes update the document without starting a render.
- Video import uses `OpenDocument()` and requests a persistable read grant so a selected asset can survive process restarts when the provider permits it.
- Rendering remains a separate explicit phase.

## Deliberate limits
The current document model is still scene-based. Full frame-accurate A/V tracks, waveforms, keyframes and proxy media remain future schema versions rather than fake UI controls.
