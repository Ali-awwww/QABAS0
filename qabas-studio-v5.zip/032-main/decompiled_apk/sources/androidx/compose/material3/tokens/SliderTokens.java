package androidx.compose.material3.tokens;

import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;
/* compiled from: SliderTokens.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\bW\n\u0002\u0018\u0002\n\u0002\b\u0003\bÀ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0014\u0010\u0003\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0019\u0010\u0007\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b\t\u0010\u0006R\u0019\u0010\u000b\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b\f\u0010\u0006R\u0019\u0010\r\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b\u000e\u0010\u0006R\u0011\u0010\u000f\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0019\u0010\u0013\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b\u0014\u0010\u0006R\u0019\u0010\u0015\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b\u0016\u0010\u0006R\u0011\u0010\u0017\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0019\u0010\u001b\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b\u001c\u0010\u0006R\u0011\u0010\u001d\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0012R\u0011\u0010\u001f\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u0012R\u0011\u0010!\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u001aR\u0014\u0010#\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b$\u0010\u0006R\u0011\u0010%\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b&\u0010\u001aR\u0014\u0010'\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b(\u0010\u0006R\u0019\u0010)\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b*\u0010\u0006R\u0011\u0010+\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b,\u0010\u001aR\u0014\u0010-\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b.\u0010\u0006R\u0011\u0010/\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b0\u0010\u001aR\u0011\u00101\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b2\u0010\u001aR\u0019\u00103\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b4\u0010\u0006R\u0011\u00105\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b6\u0010\u001aR\u0011\u00107\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b8\u0010\u001aR\u0011\u00109\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b:\u0010\u001aR\u0019\u0010;\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b<\u0010\u0006R\u0011\u0010=\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b>\u0010\u0012R\u0019\u0010?\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b@\u0010\u0006R\u0011\u0010A\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\bB\u0010\u001aR\u0019\u0010C\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\bD\u0010\u0006R\u0011\u0010E\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\bF\u0010\u001aR\u0014\u0010G\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\bH\u0010\u0006R\u0011\u0010I\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\bJ\u0010\u001aR\u0019\u0010K\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\bL\u0010\u0006R\u0011\u0010M\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\bN\u0010\u0012R\u0011\u0010O\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\bP\u0010\u001aR\u0011\u0010Q\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\bR\u0010\u001aR\u0011\u0010S\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\bT\u0010\u001aR\u0011\u0010U\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\bV\u0010\u001aR\u0019\u0010W\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\bX\u0010\u0006R\u0011\u0010Y\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\bZ\u0010\u001aR\u0011\u0010[\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b\\\u0010\u001aR\u0011\u0010]\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b^\u0010\u001aR\u0011\u0010_\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b`\u0010\u001aR\u0011\u0010a\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\bb\u0010\u001aR\u0011\u0010c\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\bd\u0010\u0012R\u0019\u0010e\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\bf\u0010\u0006R\u0019\u0010g\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\bh\u0010\u0006R\u0019\u0010i\u001a\u00020\bø\u0001\u0000ø\u0001\u0001¢\u0006\n\n\u0002\u0010\n\u001a\u0004\bj\u0010\u0006R\u0011\u0010k\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\bl\u0010\u001aR\u0011\u0010m\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\bn\u0010\u001aR\u0011\u0010o\u001a\u00020p¢\u0006\b\n\u0000\u001a\u0004\bq\u0010r\u0082\u0002\u000b\n\u0005\b¡\u001e0\u0001\n\u0002\b!¨\u0006s"}, d2 = {"Landroidx/compose/material3/tokens/SliderTokens;", "", "()V", "ActiveContainerOpacity", "", "getActiveContainerOpacity", "()F", "ActiveHandleHeight", "Landroidx/compose/ui/unit/Dp;", "getActiveHandleHeight-D9Ej5fM", "F", "ActiveHandleLeadingSpace", "getActiveHandleLeadingSpace-D9Ej5fM", "ActiveHandlePadding", "getActiveHandlePadding-D9Ej5fM", "ActiveHandleShape", "Landroidx/compose/material3/tokens/ShapeKeyTokens;", "getActiveHandleShape", "()Landroidx/compose/material3/tokens/ShapeKeyTokens;", "ActiveHandleTrailingSpace", "getActiveHandleTrailingSpace-D9Ej5fM", "ActiveHandleWidth", "getActiveHandleWidth-D9Ej5fM", "ActiveTrackColor", "Landroidx/compose/material3/tokens/ColorSchemeKeyTokens;", "getActiveTrackColor", "()Landroidx/compose/material3/tokens/ColorSchemeKeyTokens;", "ActiveTrackHeight", "getActiveTrackHeight-D9Ej5fM", "ActiveTrackShape", "getActiveTrackShape", "ActiveTrackShapeLeading", "getActiveTrackShapeLeading", "DisabledActiveTrackColor", "getDisabledActiveTrackColor", "DisabledActiveTrackOpacity", "getDisabledActiveTrackOpacity", "DisabledHandleColor", "getDisabledHandleColor", "DisabledHandleOpacity", "getDisabledHandleOpacity", "DisabledHandleWidth", "getDisabledHandleWidth-D9Ej5fM", "DisabledInactiveTrackColor", "getDisabledInactiveTrackColor", "DisabledInactiveTrackOpacity", "getDisabledInactiveTrackOpacity", "DisabledStopColor", "getDisabledStopColor", "FocusActiveTrackColor", "getFocusActiveTrackColor", "FocusHandleWidth", "getFocusHandleWidth-D9Ej5fM", "FocusInactiveTrackColor", "getFocusInactiveTrackColor", "FocusStopColor", "getFocusStopColor", "HandleColor", "getHandleColor", "HandleHeight", "getHandleHeight-D9Ej5fM", "HandleShape", "getHandleShape", "HandleWidth", "getHandleWidth-D9Ej5fM", "HoverHandleColor", "getHoverHandleColor", "HoverHandleWidth", "getHoverHandleWidth-D9Ej5fM", "HoverStopColor", "getHoverStopColor", "InactiveContainerOpacity", "getInactiveContainerOpacity", "InactiveTrackColor", "getInactiveTrackColor", "InactiveTrackHeight", "getInactiveTrackHeight-D9Ej5fM", "InactiveTrackShape", "getInactiveTrackShape", "LabelContainerColor", "getLabelContainerColor", "LabelTextColor", "getLabelTextColor", "PressedActiveTrackColor", "getPressedActiveTrackColor", "PressedHandleColor", "getPressedHandleColor", "PressedHandleWidth", "getPressedHandleWidth-D9Ej5fM", "PressedInactiveTrackColor", "getPressedInactiveTrackColor", "PressedStopColor", "getPressedStopColor", "SliderActiveHandleColor", "getSliderActiveHandleColor", "StopIndicatorColor", "getStopIndicatorColor", "StopIndicatorColorSelected", "getStopIndicatorColorSelected", "StopIndicatorShape", "getStopIndicatorShape", "StopIndicatorSize", "getStopIndicatorSize-D9Ej5fM", "StopIndicatorTrailingSpace", "getStopIndicatorTrailingSpace-D9Ej5fM", "ValueIndicatorActiveBottomSpace", "getValueIndicatorActiveBottomSpace-D9Ej5fM", "ValueIndicatorContainerColor", "getValueIndicatorContainerColor", "ValueIndicatorLabelTextColor", "getValueIndicatorLabelTextColor", "ValueIndicatorLabelTextFont", "Landroidx/compose/material3/tokens/TypographyKeyTokens;", "getValueIndicatorLabelTextFont", "()Landroidx/compose/material3/tokens/TypographyKeyTokens;", "material3_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* loaded from: classes6.dex */
public final class SliderTokens {
    public static final int $stable = 0;
    public static final SliderTokens INSTANCE = new SliderTokens();
    private static final float ActiveContainerOpacity = 1.0f;
    private static final float ActiveHandleHeight = Dp.m6633constructorimpl((float) 44.0d);
    private static final float ActiveHandleLeadingSpace = Dp.m6633constructorimpl((float) 6.0d);
    private static final float ActiveHandlePadding = Dp.m6633constructorimpl((float) 6.0d);
    private static final ShapeKeyTokens ActiveHandleShape = ShapeKeyTokens.CornerFull;
    private static final float ActiveHandleTrailingSpace = Dp.m6633constructorimpl((float) 6.0d);
    private static final float ActiveHandleWidth = Dp.m6633constructorimpl((float) 4.0d);
    private static final ColorSchemeKeyTokens ActiveTrackColor = ColorSchemeKeyTokens.Primary;
    private static final float ActiveTrackHeight = Dp.m6633constructorimpl((float) 16.0d);
    private static final ShapeKeyTokens ActiveTrackShape = ShapeKeyTokens.CornerFull;
    private static final ShapeKeyTokens ActiveTrackShapeLeading = ShapeKeyTokens.CornerFull;
    private static final ColorSchemeKeyTokens DisabledActiveTrackColor = ColorSchemeKeyTokens.OnSurface;
    private static final float DisabledActiveTrackOpacity = 0.38f;
    private static final ColorSchemeKeyTokens DisabledHandleColor = ColorSchemeKeyTokens.OnSurface;
    private static final float DisabledHandleOpacity = 0.38f;
    private static final float DisabledHandleWidth = Dp.m6633constructorimpl((float) 4.0d);
    private static final ColorSchemeKeyTokens DisabledInactiveTrackColor = ColorSchemeKeyTokens.OnSurface;
    private static final float DisabledInactiveTrackOpacity = 0.12f;
    private static final ColorSchemeKeyTokens DisabledStopColor = ColorSchemeKeyTokens.OnSurface;
    private static final ColorSchemeKeyTokens FocusActiveTrackColor = ColorSchemeKeyTokens.Primary;
    private static final float FocusHandleWidth = Dp.m6633constructorimpl((float) 2.0d);
    private static final ColorSchemeKeyTokens FocusInactiveTrackColor = ColorSchemeKeyTokens.SecondaryContainer;
    private static final ColorSchemeKeyTokens FocusStopColor = ColorSchemeKeyTokens.Primary;
    private static final ColorSchemeKeyTokens HandleColor = ColorSchemeKeyTokens.Primary;
    private static final float HandleHeight = Dp.m6633constructorimpl((float) 44.0d);
    private static final ShapeKeyTokens HandleShape = ShapeKeyTokens.CornerFull;
    private static final float HandleWidth = Dp.m6633constructorimpl((float) 4.0d);
    private static final ColorSchemeKeyTokens HoverHandleColor = ColorSchemeKeyTokens.Primary;
    private static final float HoverHandleWidth = Dp.m6633constructorimpl((float) 4.0d);
    private static final ColorSchemeKeyTokens HoverStopColor = ColorSchemeKeyTokens.Primary;
    private static final float InactiveContainerOpacity = 1.0f;
    private static final ColorSchemeKeyTokens InactiveTrackColor = ColorSchemeKeyTokens.SecondaryContainer;
    private static final float InactiveTrackHeight = Dp.m6633constructorimpl((float) 16.0d);
    private static final ShapeKeyTokens InactiveTrackShape = ShapeKeyTokens.CornerFull;
    private static final ColorSchemeKeyTokens LabelContainerColor = ColorSchemeKeyTokens.Primary;
    private static final ColorSchemeKeyTokens LabelTextColor = ColorSchemeKeyTokens.InverseOnSurface;
    private static final ColorSchemeKeyTokens PressedActiveTrackColor = ColorSchemeKeyTokens.Primary;
    private static final ColorSchemeKeyTokens PressedHandleColor = ColorSchemeKeyTokens.Primary;
    private static final float PressedHandleWidth = Dp.m6633constructorimpl((float) 2.0d);
    private static final ColorSchemeKeyTokens PressedInactiveTrackColor = ColorSchemeKeyTokens.SecondaryContainer;
    private static final ColorSchemeKeyTokens PressedStopColor = ColorSchemeKeyTokens.Primary;
    private static final ColorSchemeKeyTokens SliderActiveHandleColor = ColorSchemeKeyTokens.Primary;
    private static final ColorSchemeKeyTokens StopIndicatorColor = ColorSchemeKeyTokens.SecondaryContainer;
    private static final ColorSchemeKeyTokens StopIndicatorColorSelected = ColorSchemeKeyTokens.SecondaryContainer;
    private static final ShapeKeyTokens StopIndicatorShape = ShapeKeyTokens.CornerFull;
    private static final float StopIndicatorSize = Dp.m6633constructorimpl((float) 4.0d);
    private static final float StopIndicatorTrailingSpace = Dp.m6633constructorimpl((float) 6.0d);
    private static final float ValueIndicatorActiveBottomSpace = Dp.m6633constructorimpl((float) 12.0d);
    private static final ColorSchemeKeyTokens ValueIndicatorContainerColor = ColorSchemeKeyTokens.InverseSurface;
    private static final ColorSchemeKeyTokens ValueIndicatorLabelTextColor = ColorSchemeKeyTokens.InverseOnSurface;
    private static final TypographyKeyTokens ValueIndicatorLabelTextFont = TypographyKeyTokens.LabelLarge;

    private SliderTokens() {
    }

    public final float getActiveContainerOpacity() {
        return ActiveContainerOpacity;
    }

    /* renamed from: getActiveHandleHeight-D9Ej5fM  reason: not valid java name */
    public final float m3490getActiveHandleHeightD9Ej5fM() {
        return ActiveHandleHeight;
    }

    /* renamed from: getActiveHandleLeadingSpace-D9Ej5fM  reason: not valid java name */
    public final float m3491getActiveHandleLeadingSpaceD9Ej5fM() {
        return ActiveHandleLeadingSpace;
    }

    /* renamed from: getActiveHandlePadding-D9Ej5fM  reason: not valid java name */
    public final float m3492getActiveHandlePaddingD9Ej5fM() {
        return ActiveHandlePadding;
    }

    public final ShapeKeyTokens getActiveHandleShape() {
        return ActiveHandleShape;
    }

    /* renamed from: getActiveHandleTrailingSpace-D9Ej5fM  reason: not valid java name */
    public final float m3493getActiveHandleTrailingSpaceD9Ej5fM() {
        return ActiveHandleTrailingSpace;
    }

    /* renamed from: getActiveHandleWidth-D9Ej5fM  reason: not valid java name */
    public final float m3494getActiveHandleWidthD9Ej5fM() {
        return ActiveHandleWidth;
    }

    public final ColorSchemeKeyTokens getActiveTrackColor() {
        return ActiveTrackColor;
    }

    /* renamed from: getActiveTrackHeight-D9Ej5fM  reason: not valid java name */
    public final float m3495getActiveTrackHeightD9Ej5fM() {
        return ActiveTrackHeight;
    }

    public final ShapeKeyTokens getActiveTrackShape() {
        return ActiveTrackShape;
    }

    public final ShapeKeyTokens getActiveTrackShapeLeading() {
        return ActiveTrackShapeLeading;
    }

    public final ColorSchemeKeyTokens getDisabledActiveTrackColor() {
        return DisabledActiveTrackColor;
    }

    public final float getDisabledActiveTrackOpacity() {
        return DisabledActiveTrackOpacity;
    }

    public final ColorSchemeKeyTokens getDisabledHandleColor() {
        return DisabledHandleColor;
    }

    public final float getDisabledHandleOpacity() {
        return DisabledHandleOpacity;
    }

    /* renamed from: getDisabledHandleWidth-D9Ej5fM  reason: not valid java name */
    public final float m3496getDisabledHandleWidthD9Ej5fM() {
        return DisabledHandleWidth;
    }

    public final ColorSchemeKeyTokens getDisabledInactiveTrackColor() {
        return DisabledInactiveTrackColor;
    }

    public final float getDisabledInactiveTrackOpacity() {
        return DisabledInactiveTrackOpacity;
    }

    public final ColorSchemeKeyTokens getDisabledStopColor() {
        return DisabledStopColor;
    }

    public final ColorSchemeKeyTokens getFocusActiveTrackColor() {
        return FocusActiveTrackColor;
    }

    /* renamed from: getFocusHandleWidth-D9Ej5fM  reason: not valid java name */
    public final float m3497getFocusHandleWidthD9Ej5fM() {
        return FocusHandleWidth;
    }

    public final ColorSchemeKeyTokens getFocusInactiveTrackColor() {
        return FocusInactiveTrackColor;
    }

    public final ColorSchemeKeyTokens getFocusStopColor() {
        return FocusStopColor;
    }

    public final ColorSchemeKeyTokens getHandleColor() {
        return HandleColor;
    }

    /* renamed from: getHandleHeight-D9Ej5fM  reason: not valid java name */
    public final float m3498getHandleHeightD9Ej5fM() {
        return HandleHeight;
    }

    public final ShapeKeyTokens getHandleShape() {
        return HandleShape;
    }

    /* renamed from: getHandleWidth-D9Ej5fM  reason: not valid java name */
    public final float m3499getHandleWidthD9Ej5fM() {
        return HandleWidth;
    }

    public final ColorSchemeKeyTokens getHoverHandleColor() {
        return HoverHandleColor;
    }

    /* renamed from: getHoverHandleWidth-D9Ej5fM  reason: not valid java name */
    public final float m3500getHoverHandleWidthD9Ej5fM() {
        return HoverHandleWidth;
    }

    public final ColorSchemeKeyTokens getHoverStopColor() {
        return HoverStopColor;
    }

    public final float getInactiveContainerOpacity() {
        return InactiveContainerOpacity;
    }

    public final ColorSchemeKeyTokens getInactiveTrackColor() {
        return InactiveTrackColor;
    }

    /* renamed from: getInactiveTrackHeight-D9Ej5fM  reason: not valid java name */
    public final float m3501getInactiveTrackHeightD9Ej5fM() {
        return InactiveTrackHeight;
    }

    public final ShapeKeyTokens getInactiveTrackShape() {
        return InactiveTrackShape;
    }

    public final ColorSchemeKeyTokens getLabelContainerColor() {
        return LabelContainerColor;
    }

    public final ColorSchemeKeyTokens getLabelTextColor() {
        return LabelTextColor;
    }

    public final ColorSchemeKeyTokens getPressedActiveTrackColor() {
        return PressedActiveTrackColor;
    }

    public final ColorSchemeKeyTokens getPressedHandleColor() {
        return PressedHandleColor;
    }

    /* renamed from: getPressedHandleWidth-D9Ej5fM  reason: not valid java name */
    public final float m3502getPressedHandleWidthD9Ej5fM() {
        return PressedHandleWidth;
    }

    public final ColorSchemeKeyTokens getPressedInactiveTrackColor() {
        return PressedInactiveTrackColor;
    }

    public final ColorSchemeKeyTokens getPressedStopColor() {
        return PressedStopColor;
    }

    public final ColorSchemeKeyTokens getSliderActiveHandleColor() {
        return SliderActiveHandleColor;
    }

    public final ColorSchemeKeyTokens getStopIndicatorColor() {
        return StopIndicatorColor;
    }

    public final ColorSchemeKeyTokens getStopIndicatorColorSelected() {
        return StopIndicatorColorSelected;
    }

    public final ShapeKeyTokens getStopIndicatorShape() {
        return StopIndicatorShape;
    }

    /* renamed from: getStopIndicatorSize-D9Ej5fM  reason: not valid java name */
    public final float m3503getStopIndicatorSizeD9Ej5fM() {
        return StopIndicatorSize;
    }

    /* renamed from: getStopIndicatorTrailingSpace-D9Ej5fM  reason: not valid java name */
    public final float m3504getStopIndicatorTrailingSpaceD9Ej5fM() {
        return StopIndicatorTrailingSpace;
    }

    /* renamed from: getValueIndicatorActiveBottomSpace-D9Ej5fM  reason: not valid java name */
    public final float m3505getValueIndicatorActiveBottomSpaceD9Ej5fM() {
        return ValueIndicatorActiveBottomSpace;
    }

    public final ColorSchemeKeyTokens getValueIndicatorContainerColor() {
        return ValueIndicatorContainerColor;
    }

    public final ColorSchemeKeyTokens getValueIndicatorLabelTextColor() {
        return ValueIndicatorLabelTextColor;
    }

    public final TypographyKeyTokens getValueIndicatorLabelTextFont() {
        return ValueIndicatorLabelTextFont;
    }
}
