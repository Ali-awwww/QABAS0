package com.example

import android.content.Context
import android.util.Log
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.roundToInt

/**
 * Qabas Brain — طبقة التخطيط والقرار التي تسبق الاستدعاء إلى Gemini أو محرك الفيديو.
 *
 * الهدف: فصل "الفهم والتخطيط والتحقق" عن "التوليد" وعن "التنفيذ".
 * Gemini/الخدمات الخارجية أدوات داخل الخطة وليست مصدر الحقيقة الوحيد.
 */
object QabasBrainEngine {
    private const val TAG = "QabasBrainEngine"

    enum class BrainStage {
        UNDERSTAND, RESEARCH, VALIDATE, PLAN, DIRECT, QUALITY_GATE
    }

    data class RequestProfile(
        val idea: String,
        val contentType: String,
        val tone: String,
        val audience: String,
        val durationSec: Int,
        val wantsEvidence: Boolean,
        val visualStyleHint: String,
        val requiresArabicCaptions: Boolean = true
    )

    data class ResearchPlan(
        val requiresQuranLookup: Boolean,
        val requiresHadithLookup: Boolean,
        val requiresGeneralFactCheck: Boolean,
        val reason: String
    )

    data class QualityGate(
        val approved: Boolean,
        val score: Int,
        val issues: List<String>,
        val warnings: List<String>
    )

    data class BrainExecutionPlan(
        val id: String = UUID.randomUUID().toString(),
        val profile: RequestProfile,
        val research: ResearchPlan,
        val selectedStyleName: String,
        val styleBrief: String,
        val editPlan: MontageDirector.EditPlan,
        val scenes: List<Scene>,
        val quality: QualityGate,
        val rationale: List<String>
    )

    suspend fun plan(
        context: Context,
        idea: String,
        contentType: String = "Reels/Shorts",
        tone: String = "خاشع",
        audience: String = "الجمهور العام",
        durationSec: Int = 30,
        styleHint: String = "",
        wantsEvidence: Boolean = true
    ): BrainExecutionPlan = withContext(Dispatchers.IO) {
        val profile = understand(
            idea = idea,
            contentType = contentType,
            tone = tone,
            audience = audience,
            durationSec = durationSec,
            styleHint = styleHint,
            wantsEvidence = wantsEvidence
        )
        val research = buildResearchPlan(profile)
        val repository = QabasBrainRepository.getInstance(context)
        val referenceMemory = repository.buildFewShotStyleMemory(profile.idea, profile.tone, limit = 3)
        val selectedStyle = selectStyle(profile)

        val editPlan = MontageDirector.createPlan(
            idea = profile.idea,
            tone = profile.tone,
            targetDurationSec = profile.durationSec,
            audience = profile.audience,
            styleDescription = buildString {
                if (profile.visualStyleHint.isNotBlank()) append("تفضيل المستخدم: ${profile.visualStyleHint}. ")
                append(referenceMemory.take(2200))
            },
            preferredStyleId = selectedStyle?.id
        )

        // التوليد النصي اختياري هنا؛ المخرج يملك fallback محليًا حقيقيًا.
        val generatedScenes = try {
            AppServices.generateScript(
                idea = profile.idea,
                styleDescription = editPlan.styleBrief,
                contentType = profile.contentType,
                contentTone = profile.tone
            )
        } catch (e: Exception) {
            Log.w(TAG, "Script generation unavailable; using directed plan", e)
            emptyList()
        }

        val directedScenes = if (generatedScenes.size >= 2) {
            MontageDirector.enhanceScenesWithPlan(
                generatedScenes,
                editPlan
            )
        } else {
            MontageDirector.toScenes(editPlan)
        }

        val finalScenes = normalizeSceneDurations(directedScenes, profile.durationSec)
        val quality = qualityGate(profile, research, finalScenes)
        val rationale = buildRationale(profile, research, editPlan, quality)

        SystemLogsManager.addLog(
            "BRAIN",
            "خطة ${profile.idea.take(36)} | ${finalScenes.size} مشاهد | جودة ${quality.score}% | ${if (quality.approved) "مقبولة" else "تحتاج مراجعة"}",
            if (quality.approved) Color(0xFF4CAF50) else Color(0xFFE8C547)
        )

        BrainExecutionPlan(
            profile = profile,
            research = research,
            selectedStyleName = editPlan.styleName,
            styleBrief = editPlan.styleBrief,
            editPlan = editPlan,
            scenes = finalScenes,
            quality = quality,
            rationale = rationale
        )
    }

    private fun understand(
        idea: String,
        contentType: String,
        tone: String,
        audience: String,
        durationSec: Int,
        styleHint: String,
        wantsEvidence: Boolean
    ): RequestProfile {
        val cleanIdea = idea.trim().ifBlank { "فكرة إيمانية عامة" }
        val lower = cleanIdea.lowercase()
        val type = contentType.ifBlank { "Reels/Shorts" }
        val inferredAudience = when {
            audience.isNotBlank() && audience != "الجمهور العام" -> audience
            lower.contains("أطفال") || lower.contains("طفل") -> "الأطفال والعائلة"
            lower.contains("شباب") || lower.contains("شاب") -> "الشباب"
            else -> "الجمهور العام"
        }
        val inferredTone = when {
            tone.isNotBlank() -> tone
            lower.contains("تحذير") || lower.contains("خطر") -> "تنبيهي رصين"
            lower.contains("رحمة") || lower.contains("فضل") -> "روحاني ملهم"
            else -> "خاشع ووقور"
        }
        return RequestProfile(
            idea = cleanIdea,
            contentType = type,
            tone = inferredTone,
            audience = inferredAudience,
            durationSec = durationSec.coerceIn(10, 120),
            wantsEvidence = wantsEvidence,
            visualStyleHint = styleHint.trim(),
            requiresArabicCaptions = true
        )
    }

    private fun buildResearchPlan(profile: RequestProfile): ResearchPlan {
        val t = profile.idea.lowercase()
        val quran = profile.wantsEvidence && listOf("آية", "القرآن", "قرآني", "سورة", "قال الله").any(t::contains)
        val hadith = profile.wantsEvidence && listOf("حديث", "النبي", "الرسول", "صحيح البخاري", "صحيح مسلم", "سنن").any(t::contains)
        val general = profile.wantsEvidence && !(quran || hadith)
        val reason = buildString {
            append("المطلوب: ${profile.audience}. ")
            when {
                quran -> append("تحتاج الفكرة تحققًا نصيًا قرآنيًا قبل إدراج نص منسوب للقرآن.")
                hadith -> append("تحتاج الفكرة تحققًا من نسبة الحديث ودرجته قبل عرضه كحديث.")
                general -> append("تحتاج الفكرة تحققًا عامًا لأي ادعاءات واقعية قبل عرضها كحقيقة.")
                else -> append("لا يوجد مصدر ديني محدد مطلوب من النص الحالي.")
            }
        }
        return ResearchPlan(quran, hadith, general, reason)
    }

    private fun selectStyle(profile: RequestProfile): StyleObject? {
        return try {
            StyleBrain.absorbedStyles.value
                .filter { profile.visualStyleHint.isBlank() || it.name.contains(profile.visualStyleHint, ignoreCase = true) || it.tags.any { tag -> profile.visualStyleHint.contains(tag, true) } }
                .maxByOrNull { it.overallScore }
                ?: StyleBrain.absorbedStyles.value.maxByOrNull { it.overallScore }
        } catch (_: Exception) {
            null
        }
    }

    private fun normalizeSceneDurations(scenes: List<Scene>, targetDuration: Int): List<Scene> {
        if (scenes.isEmpty()) return emptyList()
        val safe = scenes.map { it.copy(durationInSeconds = it.durationInSeconds.coerceIn(3, 30)) }
        val total = safe.sumOf { it.durationInSeconds }
        if (total <= 0) return safe
        val ratio = targetDuration.toDouble() / total.toDouble()
        return safe.map { scene ->
            scene.copy(durationInSeconds = (scene.durationInSeconds * ratio).roundToInt().coerceIn(3, 30))
        }
    }

    private fun qualityGate(profile: RequestProfile, research: ResearchPlan, scenes: List<Scene>): QualityGate {
        val issues = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        if (scenes.isEmpty()) issues += "لم يتم إنتاج أي مشاهد قابلة للتنفيذ."
        if (scenes.any { it.description.isBlank() }) issues += "يوجد مشهد بلا وصف بصري."
        if (scenes.any { it.durationInSeconds < 3 }) issues += "يوجد مشهد أقصر من الحد الأدنى للتنفيذ."
        if (research.requiresQuranLookup || research.requiresHadithLookup) {
            warnings += "يوجد محتوى ديني يحتاج تحقق المصدر قبل النشر؛ العقل لا يعتبر التوليد وحده توثيقًا."
        }
        if (profile.idea.length < 8) warnings += "الفكرة قصيرة جدًا؛ قد ينتج عنها تنويع بصري محدود."
        if (scenes.size == 1) warnings += "المشهد الواحد يحد من الإيقاع؛ يفضل أكثر من مشهد عند توفر مادة كافية."
        val score = (100 - issues.size * 28 - warnings.size * 7).coerceIn(0, 100)
        return QualityGate(approved = issues.isEmpty(), score = score, issues = issues, warnings = warnings)
    }

    private fun buildRationale(
        profile: RequestProfile,
        research: ResearchPlan,
        editPlan: MontageDirector.EditPlan,
        quality: QualityGate
    ): List<String> = buildList {
        add("فهم الطلب: ${profile.audience} • ${profile.contentType} • ${profile.durationSec} ثانية")
        add(research.reason)
        add("الأسلوب المختار: ${editPlan.styleName}")
        add("المخرج أنشأ ${editPlan.scenes.size} مشاهد قبل التنفيذ")
        add(if (quality.approved) "بوابة الجودة: مسموح بالتنفيذ" else "بوابة الجودة: يلزم تدخل قبل التنفيذ")
    }

}
