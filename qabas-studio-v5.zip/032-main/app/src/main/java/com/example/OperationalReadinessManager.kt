package com.example

import android.content.Context
import androidx.compose.ui.graphics.Color
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ServiceReadiness(
    val name: String,
    val weight: Int,
    val isConfigured: Boolean,
    val description: String,
    val activeFeature: String
)

data class ReadinessReport(
    val percentage: Int,
    val statusTitle: String,
    val statusDescription: String,
    val activeServicesCount: Int,
    val totalServicesCount: Int,
    val services: List<ServiceReadiness>,
    val lastError: String? = null
)

object OperationalReadinessManager {

    private var lastRecordedError: String? = null
    private var lastRecordedTime: String? = null

    fun recordLastError(service: String, message: String) {
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val timeStr = timeFormat.format(Date())
        val formatted = "[$service $timeStr] $message"
        lastRecordedError = formatted
        lastRecordedTime = timeStr
        SystemLogsManager.addLog("ERROR", formatted, Color(0xFFEF4444))
    }

    fun recordLastError(message: String) {
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val timeStr = timeFormat.format(Date())
        val formatted = "[$timeStr] $message"
        lastRecordedError = formatted
        lastRecordedTime = timeStr
        SystemLogsManager.addLog("ERROR", formatted, Color(0xFFEF4444))
    }

    fun getLastError(): String? = lastRecordedError

    fun clearLastError() {
        lastRecordedError = null
        lastRecordedTime = null
    }

    fun calculateReadiness(context: Context, customKeys: Map<String, String>? = null): ReadinessReport {
        val prefs = context.getSharedPreferences("qabas_prefs", Context.MODE_PRIVATE)

        fun getKey(name: String): String {
            return customKeys?.get(name) ?: prefs.getString(name, "") ?: ""
        }

        fun isKeyValid(key: String): Boolean {
            val trimmed = key.trim()
            return trimmed.isNotBlank() && 
                   trimmed != "YOUR_GEMINI_API_KEY" && 
                   !trimmed.equals("placeholder", ignoreCase = true) &&
                   !trimmed.startsWith("YOUR_")
        }

        val geminiKey = getKey("gemini_key")
        val groqKey = getKey("groq_key")
        val huggingfaceKey = getKey("huggingface_key")
        val pexelsKey = getKey("pexels_key")
        val pixabayKey = getKey("pixabay_key")
        val firebaseKey = getKey("firebase_key")

        val hasGemini = isKeyValid(geminiKey)
        val hasGroq = isKeyValid(groqKey)
        val hasHuggingFace = isKeyValid(huggingfaceKey)
        val hasPexels = isKeyValid(pexelsKey)
        val hasPixabay = isKeyValid(pixabayKey)
        val hasFirebase = isKeyValid(firebaseKey)

        val services = listOf(
            ServiceReadiness(
                name = "Gemini API (Google AI)",
                weight = 45,
                isConfigured = hasGemini,
                description = "المساعد الدعوي، صياغة السكريبتات، وتحليل الأفكار الإسلامية، والرؤية البصرية",
                activeFeature = if (hasGemini) "متصل بمفتاح Gemini المحفوظ" else "غير مفعّل — لا يتم احتساب هذا كاتصال حقيقي"
            ),
            ServiceReadiness(
                name = "Groq API (Ultra Fast AI)",
                weight = 20,
                isConfigured = hasGroq,
                description = "توليد الخطافات الفورية والوسوم السريعة (Llama 3.3)",
                activeFeature = if (hasGroq) "متصل بمفتاح Groq المحفوظ" else "غير مفعّل"
            ),
            ServiceReadiness(
                name = "Pexels & Pixabay APIs",
                weight = 20,
                isConfigured = hasPexels || hasPixabay,
                description = "جلب فيديوهات وصور المعالم الإسلامية والطبيعة HD",
                activeFeature = if (hasPexels || hasPixabay) "جلب وسائط حية من المكتبات العالمية" else "استخدام الوسائط المحلية المخزنة"
            ),
            ServiceReadiness(
                name = "Hugging Face AI",
                weight = 10,
                isConfigured = hasHuggingFace,
                description = "توليد صور وخلفيات إسلامية مخصصة بالذكاء الاصطناعي (FLUX)",
                activeFeature = if (hasHuggingFace) "توليد صور الذكاء الاصطناعي مفعل" else "استخدام تصاميم الاستوديو الجاهزة"
            ),
            ServiceReadiness(
                name = "Firebase Cloud Database",
                weight = 5,
                isConfigured = hasFirebase,
                description = "حفظ المشاريع سحابياً ومزامنة مجتمع الإلهام",
                activeFeature = if (hasFirebase) "مزامنة سحابية حقيقية مفعلة" else "حفظ محلي في قاعدة بيانات Room"
            )
        )

        var totalScore = 0
        var activeCount = 0

        services.forEach {
            if (it.isConfigured) {
                totalScore += it.weight
                activeCount++
            }
        }

        val (title, desc) = when {
            totalScore >= 95 -> Pair(
                "جميع الخدمات الأساسية المهيأة متاحة 🟢",
                "كل خدمة محسوبة في هذا التقرير مهيأة محليًا، لكن الجاهزية الكاملة للنشر تعتمد أيضًا على صلاحية الحسابات والـAPIs الفعلية."
            )
            totalScore >= 70 -> Pair(
                "جاهزية تشغيل عالية ($totalScore%) 🚀",
                "المحركات الأساسية (النصوص، الصوت، والوسائط) متصلة بالسيرفرات المباشرة بنجاح."
            )
            totalScore >= 35 -> Pair(
                "الذكاء الاصطناعي مهيأ ($totalScore%) 🟢",
                "تتوفر مفاتيح لخدمات الذكاء الاصطناعي المطلوبة. الجاهزية هنا تعكس التهيئة، لا ضمان نجاح كل طلب خارجي."
            )
            else -> Pair(
                "التهيئة الأساسية غير مكتملة ($totalScore%) 🟡",
                "يمكن للتطبيق العمل بالوظائف المحلية، لكن بعض خدمات الذكاء الاصطناعي والوسائط لن تعمل قبل إعداد مفاتيحها."
            )
        }

        return ReadinessReport(
            percentage = totalScore,
            statusTitle = title,
            statusDescription = desc,
            activeServicesCount = activeCount,
            totalServicesCount = services.size,
            services = services,
            lastError = lastRecordedError
        )
    }
}
