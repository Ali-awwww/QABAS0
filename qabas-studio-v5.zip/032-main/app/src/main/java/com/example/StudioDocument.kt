package com.example

import org.json.JSONArray
import org.json.JSONObject

/** Canonical, serializable editor document used by the studio session. */
data class StudioDocument(
    val version: Int = 1,
    val title: String = "مشروع جديد",
    val ratio: String = "9:16",
    val fps: Int = 30,
    val quality: String = "1080p",
    val scenes: List<Scene> = emptyList()
) {
    fun toJson(): String {
        val root = JSONObject().apply {
            put("version", version)
            put("title", title)
            put("ratio", ratio)
            put("fps", fps)
            put("quality", quality)
            put("scenes", JSONArray().apply {
                scenes.forEach { s ->
                    put(JSONObject().apply {
                        put("title", s.title)
                        put("description", s.description)
                        put("duration", s.durationInSeconds)
                        put("visualEffect", s.visualEffect)
                        put("tempo", s.tempo)
                        put("transitionType", s.transitionType)
                        put("mediaUrl", s.mediaUrl ?: JSONObject.NULL)
                    })
                }
            })
        }
        return root.toString()
    }

    companion object {
        fun fromJson(raw: String): StudioDocument? = runCatching {
            val root = JSONObject(raw)
            val scenes = buildList {
                val array = root.optJSONArray("scenes") ?: JSONArray()
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    add(
                        Scene(
                            title = item.optString("title"),
                            description = item.optString("description"),
                            durationInSeconds = item.optInt("duration", 4).coerceAtLeast(1),
                            visualEffect = item.optString("visualEffect", "بدون"),
                            tempo = item.optString("tempo", "عادي"),
                            transitionType = item.optString("transitionType", "Fade"),
                            mediaUrl = item.optString("mediaUrl").takeUnless { it.isBlank() || it == "null" }
                        )
                    )
                }
            }
            StudioDocument(
                version = root.optInt("version", 1),
                title = root.optString("title", "مشروع جديد"),
                ratio = root.optString("ratio", "9:16"),
                fps = root.optInt("fps", 30),
                quality = root.optString("quality", "1080p"),
                scenes = scenes
            )
        }.getOrNull()
    }
}
