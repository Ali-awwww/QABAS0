package com.example

import android.net.Uri
import android.view.ViewGroup
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private enum class StudioTool(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    MEDIA("الوسائط", Icons.Default.VideoLibrary),
    AUDIO("الصوت", Icons.Default.MusicNote),
    TEXT("النص", Icons.Default.TextFields),
    TRANSITION("الانتقال", Icons.Default.AutoAwesome),
    COLOR("اللون", Icons.Default.ColorLens),
    DETAILS("التفاصيل", Icons.Default.Tune)
}

private data class StudioProject(
    val ratio: String = "9:16",
    val fps: Int = 30,
    val quality: String = "1080p",
    val title: String = "مشروع جديد"
)

private fun formatTime(value: Float): String {
    val total = value.roundToInt().coerceAtLeast(0)
    return "%02d:%02d".format(total / 60, total % 60)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioWorkspaceScreen(
    scenes: List<Scene>,
    projectTitle: String,
    initialRatio: String,
    onUpdateScenes: (List<Scene>) -> Unit,
    onBack: () -> Unit,
    onRender: () -> Unit
) {
    val context = LocalContext.current
    var editableScenes by remember(scenes) { mutableStateOf(scenes.ifEmpty { listOf(Scene("المقدمة", "ابدأ برسالة واضحة ومشهد قوي", 4)) }) }
    var studioProject by remember(projectTitle, initialRatio) { mutableStateOf(StudioProject(title = projectTitle, ratio = initialRatio.ifBlank { "9:16" })) }
    var selectedScene by remember { mutableIntStateOf(0) }
    var selectedTool by remember { mutableStateOf(StudioTool.MEDIA) }
    var isPlaying by remember { mutableStateOf(false) }
    var playhead by remember { mutableFloatStateOf(0f) }
    var showExport by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showAddScene by remember { mutableStateOf(false) }
    var undoStack by remember { mutableStateOf(listOf(editableScenes)) }
    var redoStack by remember { mutableStateOf(emptyList<List<Scene>>()) }
    val scope = rememberCoroutineScope()
    val draftKey = remember(studioProject.title) { "studio_draft_${studioProject.title.trim().ifBlank { "default" }.hashCode()}" }

    fun restoreDraft() {
        val raw = context.getSharedPreferences("qabas_studio", android.content.Context.MODE_PRIVATE).getString(draftKey, null)
        val draft = raw?.let { StudioDocument.fromJson(it) }
        if (draft != null && draft.scenes.isNotEmpty()) {
            editableScenes = draft.scenes
            undoStack = listOf(draft.scenes)
            redoStack = emptyList()
            selectedScene = 0
            onUpdateScenes(draft.scenes)
        }
    }

    fun saveDraft() {
        val doc = StudioDocument(title = studioProject.title, ratio = studioProject.ratio, fps = studioProject.fps, quality = studioProject.quality, scenes = editableScenes)
        context.getSharedPreferences("qabas_studio", android.content.Context.MODE_PRIVATE).edit().putString(draftKey, doc.toJson()).apply()
    }

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && editableScenes.isNotEmpty()) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            commit(editableScenes.updated(selectedScene) { it.copy(mediaUrl = uri.toString()) })
        }
    }

    val totalDuration = editableScenes.sumOf { it.durationInSeconds.coerceAtLeast(1) }.toFloat().coerceAtLeast(1f)
    val activeIndex = remember(playhead, editableScenes) {
        var acc = 0f
        var idx = 0
        editableScenes.forEachIndexed { index, scene ->
            acc += scene.durationInSeconds.coerceAtLeast(1)
            if (playhead < acc && idx == 0) idx = index
        }
        idx.coerceIn(0, editableScenes.lastIndex.coerceAtLeast(0))
    }

    LaunchedEffect(isPlaying, totalDuration) {
        if (isPlaying) {
            while (isPlaying && playhead < totalDuration) {
                delay(50)
                playhead = (playhead + 0.05f).coerceAtMost(totalDuration)
                if (playhead >= totalDuration) isPlaying = false
            }
        }
    }

    LaunchedEffect(activeIndex) { if (isPlaying) selectedScene = activeIndex }
    BackHandler { onBack() }

    fun commit(updated: List<Scene>, recordHistory: Boolean = true) {
        if (updated == editableScenes) return
        if (recordHistory) undoStack = (undoStack + listOf(editableScenes)).takeLast(50)
        editableScenes = updated
        redoStack = emptyList()
        onUpdateScenes(updated)
        selectedScene = selectedScene.coerceIn(0, updated.lastIndex.coerceAtLeast(0))
        saveDraft()
    }

    LaunchedEffect(Unit) { restoreDraft() }

    Scaffold(
        containerColor = DeepSlate,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(studioProject.title.ifBlank { "استوديو قبس" }, color = TextPrimary, fontFamily = CairoFont, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("محرر إنتاج متكامل", color = TextSecondary, fontFamily = CairoFont, fontSize = 11.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = GoldPrimary) }
                },
                actions = {
                    Surface(shape = RoundedCornerShape(8.dp), color = CardSurface) {
                        Text(studioProject.ratio, color = GoldPrimary, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
                    }
                    IconButton(enabled = undoStack.size > 1, onClick = {
                        if (undoStack.size > 1) {
                            val previous = undoStack.last()
                            undoStack = undoStack.dropLast(1)
                            redoStack = (redoStack + listOf(editableScenes)).takeLast(50)
                            editableScenes = previous
                            onUpdateScenes(previous)
                            selectedScene = selectedScene.coerceIn(0, previous.lastIndex.coerceAtLeast(0))
                            saveDraft()
                        }
                    }) { Icon(Icons.Default.Undo, "تراجع", tint = if (undoStack.size > 1) TextSecondary else TextSecondary.copy(alpha = 0.35f)) }
                    IconButton(enabled = redoStack.isNotEmpty(), onClick = {
                        val next = redoStack.lastOrNull() ?: return@IconButton
                        redoStack = redoStack.dropLast(1)
                        undoStack = (undoStack + listOf(editableScenes)).takeLast(50)
                        editableScenes = next
                        onUpdateScenes(next)
                        selectedScene = selectedScene.coerceIn(0, next.lastIndex.coerceAtLeast(0))
                        saveDraft()
                    }) { Icon(Icons.Default.Redo, "إعادة", tint = if (redoStack.isNotEmpty()) TextSecondary else TextSecondary.copy(alpha = 0.35f)) }
                    IconButton(onClick = { saveDraft(); android.widget.Toast.makeText(context, "تم حفظ المسودة محليًا", android.widget.Toast.LENGTH_SHORT).show() }) { Icon(Icons.Default.Save, "حفظ", tint = GoldPrimary) }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "إعدادات المشروع", tint = TextSecondary) }
                    TextButton(onClick = { showExport = true }) { Text("تصدير", color = GoldPrimary, fontWeight = FontWeight.Bold) }
                }
            )
        },
        bottomBar = {
            Surface(color = Color(0xFF080C14), tonalElevation = 6.dp) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    StudioTool.values().forEach { tool ->
                        val selected = selectedTool == tool
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { selectedTool = tool }.padding(horizontal = 10.dp, vertical = 5.dp)) {
                            Icon(tool.icon, null, tint = if (selected) GoldPrimary else TextSecondary, modifier = Modifier.size(20.dp))
                            Text(tool.title, color = if (selected) GoldPrimary else TextSecondary, fontSize = 10.sp, fontFamily = CairoFont)
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().weight(1f)) {
                // Tool inspector
                Surface(modifier = Modifier.width(112.dp).fillMaxHeight(), color = Color(0xFF090E17), tonalElevation = 2.dp) {
                    ToolInspector(selectedTool, editableScenes, selectedScene, onChangeScene = { commit(it) }, onImportMedia = { mediaPicker.launch(arrayOf("video/*")) })
                }

                // Preview
                Column(Modifier.weight(1f).fillMaxHeight()) {
                    Box(Modifier.fillMaxWidth().weight(1f).padding(10.dp), contentAlignment = Alignment.Center) {
                        val scene = editableScenes.getOrNull(activeIndex)
                        StudioPreview(scene = scene, isPlaying = isPlaying, ratio = studioProject.ratio, onTogglePlay = { isPlaying = !isPlaying })
                    }
                    StudioTransport(playhead, totalDuration, isPlaying, onPlay = { isPlaying = !isPlaying }, onSeek = { playhead = it })
                }
            }

            // Timeline
            Surface(color = Color(0xFF0A101B), border = BorderStroke(1.dp, Color(0xFF1D2938))) {
                Column {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("المخطط الزمني", color = TextPrimary, fontFamily = CairoFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.weight(1f))
                        Text("${editableScenes.size} مشاهد · ${formatTime(totalDuration)}", color = TextSecondary, fontSize = 11.sp)
                        IconButton(onClick = { showAddScene = true }) { Icon(Icons.Default.Add, "إضافة مشهد", tint = GoldPrimary) }
                    }
                    Timeline(
                        scenes = editableScenes,
                        selectedIndex = selectedScene,
                        playhead = playhead,
                        onSelect = { selectedScene = it },
                        onSeek = { playhead = it },
                        onDelete = { index ->
                            if (editableScenes.size > 1) commit(editableScenes.toMutableList().also { it.removeAt(index) })
                        },
                        onDuplicate = { index ->
                            val list = editableScenes.toMutableList()
                            list.add((index + 1).coerceAtMost(list.size), list[index].copy(title = list[index].title + " — نسخة"))
                            commit(list)
                        },
                        onMove = { from, to ->
                            if (to in editableScenes.indices) {
                                val list = editableScenes.toMutableList()
                                val item = list.removeAt(from)
                                list.add(to, item)
                                selectedScene = to
                                commit(list)
                            }
                        }
                    )
                }
            }
        }
    }

    if (showAddScene) {
        var title by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var duration by remember { mutableStateOf("4") }
        AlertDialog(
            onDismissRequest = { showAddScene = false },
            title = { Text("إضافة مشهد", fontFamily = CairoFont) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("اسم المشهد") })
                    OutlinedTextField(description, { description = it }, label = { Text("الوصف") })
                    OutlinedTextField(duration, { duration = it.filter(Char::isDigit) }, label = { Text("الثواني") })
                }
            },
            confirmButton = {
                Button(onClick = { commit(editableScenes + Scene(title.ifBlank { "مشهد جديد" }, description, duration.toIntOrNull()?.coerceAtLeast(1) ?: 4)); showAddScene = false }, colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = DeepSlate)) { Text("إضافة") }
            },
            dismissButton = { TextButton(onClick = { showAddScene = false }) { Text("إلغاء") } }
        )
    }

    if (showExport) {
        AlertDialog(
            onDismissRequest = { showExport = false },
            title = { Text("تصدير المشروع", fontFamily = CairoFont, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الاستوديو سيستخدم هذه الخطة عند التصدير:", color = TextSecondary)
                    Text("${studioProject.ratio} · ${studioProject.quality} · ${studioProject.fps}fps", color = GoldPrimary, fontWeight = FontWeight.Bold)
                    Text("لن يتم الإعلان عن نجاح التصدير قبل وجود ملف MP4 صالح.", color = TextSecondary, fontSize = 12.sp)
                }
            },
            confirmButton = { Button(onClick = { showExport = false; onRender() }, colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = DeepSlate)) { Text("بدء الرندر") } },
            dismissButton = { TextButton(onClick = { showExport = false }) { Text("إلغاء") } }
        )
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("إعدادات المشروع", fontFamily = CairoFont, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("نسبة الأبعاد", color = TextSecondary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        itemsIndexed(listOf("9:16", "16:9", "1:1", "4:5")) { _, ratio ->
                            FilterChip(selected = studioProject.ratio == ratio, onClick = { studioProject = studioProject.copy(ratio = ratio); saveDraft() }, label = { Text(ratio) })
                        }
                    }
                    Text("الجودة", color = TextSecondary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        itemsIndexed(listOf("720p", "1080p")) { _, q ->
                            FilterChip(selected = studioProject.quality == q, onClick = { studioProject = studioProject.copy(quality = q); saveDraft() }, label = { Text(q) })
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("تم", color = GoldPrimary) } }
        )
    }
}

@Composable
private fun ToolInspector(tool: StudioTool, scenes: List<Scene>, selectedIndex: Int, onChangeScene: (List<Scene>) -> Unit, onImportMedia: () -> Unit) {
    val scene = scenes.getOrNull(selectedIndex)
    var editTextOpen by remember(scene?.title, scene?.description) { mutableStateOf(false) }
    var editTitle by remember(scene?.title) { mutableStateOf(scene?.title.orEmpty()) }
    var editDescription by remember(scene?.description) { mutableStateOf(scene?.description.orEmpty()) }
    LazyColumn(Modifier.fillMaxSize().padding(8.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        item {
            Text(tool.title, color = GoldPrimary, fontFamily = CairoFont, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(4.dp))
        }
        when (tool) {
            StudioTool.MEDIA -> {
                item { InspectorAction("استيراد فيديو", Icons.Default.VideoLibrary, onImportMedia) }
                item { InspectorAction("إزالة الوسيط", Icons.Default.Delete) { if (scene != null) onChangeScene(scenes.updated(selectedIndex) { it.copy(mediaUrl = null) }) } }
            }
            StudioTool.AUDIO -> {
                item { Text("الصوت يُدار عبر مسار المعالجة، ويمكن تعديل مصدره من إعدادات المشروع.", color = TextSecondary, fontSize = 11.sp, fontFamily = CairoFont) }
                item { InspectorAction("مصدر الصوت", Icons.Default.MusicNote, enabled = false) {} }
            }
            StudioTool.TEXT -> {
                item { InspectorAction("إضافة عنوان", Icons.Default.Title) { if (scene != null) onChangeScene(scenes.updated(selectedIndex) { it.copy(title = if (it.title.isBlank()) "عنوان جديد" else it.title) }) } }
                item { InspectorAction("تعديل النص", Icons.Default.Edit) { if (scene != null) { editTitle = scene.title; editDescription = scene.description; editTextOpen = true } } }
            }
            StudioTool.TRANSITION -> {
                item { InspectorAction("Fade", Icons.Default.BlurOn) { if (scene != null) onChangeScene(scenes.updated(selectedIndex) { it.copy(transitionType = "Fade") }) } }
                item { InspectorAction("Cut", Icons.Default.CallMade) { if (scene != null) onChangeScene(scenes.updated(selectedIndex) { it.copy(transitionType = "Cut") }) } }
                item { InspectorAction("Dissolve", Icons.Default.AutoAwesomeMotion) { if (scene != null) onChangeScene(scenes.updated(selectedIndex) { it.copy(transitionType = "Dissolve") }) } }
            }
            StudioTool.COLOR -> {
                item { InspectorAction("Cinematic", Icons.Default.MovieFilter) { if (scene != null) onChangeScene(scenes.updated(selectedIndex) { it.copy(visualEffect = "Cinematic") }) } }
                item { InspectorAction("Natural", Icons.Default.WbSunny) { if (scene != null) onChangeScene(scenes.updated(selectedIndex) { it.copy(visualEffect = "Natural") }) } }
            }
            StudioTool.DETAILS -> {
                item { Text("مدة المشهد", color = TextSecondary, fontSize = 11.sp) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(-1, 1).forEach { delta ->
                            OutlinedButton(enabled = scene != null && scene.durationInSeconds + delta > 0, onClick = { if (scene != null) onChangeScene(scenes.updated(selectedIndex) { it.copy(durationInSeconds = (it.durationInSeconds + delta).coerceAtLeast(1)) }) }, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(38.dp)) {
                                Text(if (delta > 0) "+" else "−")
                            }
                        }
                    }
                }
            }
        }
    }

    if (editTextOpen && scene != null) {
        AlertDialog(
            onDismissRequest = { editTextOpen = false },
            title = { Text("تحرير نص المشهد", fontFamily = CairoFont) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(editTitle, { editTitle = it }, label = { Text("العنوان") })
                    OutlinedTextField(editDescription, { editDescription = it }, label = { Text("النص") }, minLines = 3)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onChangeScene(scenes.updated(selectedIndex) { it.copy(title = editTitle, description = editDescription) })
                    editTextOpen = false
                }) { Text("حفظ", color = GoldPrimary) }
            },
            dismissButton = { TextButton(onClick = { editTextOpen = false }) { Text("إلغاء") } }
        )
    }
}

private fun InspectorAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, enabled: Boolean = true, onClick: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onClick), shape = RoundedCornerShape(9.dp), color = CardSurface, border = BorderStroke(1.dp, Color(0xFF1D2938))) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, null, tint = if (enabled) GoldPrimary else TextSecondary, modifier = Modifier.size(17.dp))
            Text(title, color = if (enabled) TextPrimary else TextSecondary, fontFamily = CairoFont, fontSize = 11.sp)
        }
    }
}

private fun List<Scene>.updated(index: Int, transform: (Scene) -> Scene): List<Scene> = mapIndexed { i, scene -> if (i == index) transform(scene) else scene }

@Composable
private fun StudioPreview(scene: Scene?, isPlaying: Boolean, ratio: String, onTogglePlay: () -> Unit) {
    val context = LocalContext.current
    val shape = RoundedCornerShape(18.dp)
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Surface(shape = shape, color = Color.Black, shadowElevation = 10.dp, modifier = Modifier.fillMaxHeight().aspectRatio(if (ratio == "16:9") 16f / 9f else if (ratio == "1:1") 1f else if (ratio == "4:5") 4f / 5f else 9f / 16f)) {
            Box(Modifier.fillMaxSize().clip(shape).clickable(onClick = onTogglePlay)) {
                val uri = scene?.mediaUrl?.let { Uri.parse(it) }
                if (uri != null && (uri.scheme == "file" || uri.scheme == "content")) {
                    AndroidView(factory = {
                        VideoView(context).apply {
                            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                            setVideoURI(uri)
                            setOnPreparedListener { mp -> mp.isLooping = true; if (isPlaying) start() }
                        }
                    }, modifier = Modifier.fillMaxSize(), update = { if (isPlaying) it.start() else it.pause() })
                } else if (!scene?.mediaUrl.isNullOrBlank()) {
                    AsyncImage(model = ImageRequest.Builder(context).data(scene?.mediaUrl).crossfade(true).build(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF111827), Color(0xFF020617)))))
                }

                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f)))))
                Column(Modifier.align(Alignment.BottomCenter).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(scene?.title ?: "لا يوجد مشهد", color = GoldPrimary, fontFamily = CairoFont, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text(scene?.description.orEmpty(), color = Color.White.copy(alpha = 0.9f), fontFamily = CairoFont, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 2)
                }
                if (!isPlaying) {
                    Surface(Modifier.align(Alignment.Center).size(58.dp), shape = CircleShape, color = Color.Black.copy(alpha = 0.55f), border = BorderStroke(1.dp, GoldPrimary)) {
                        Icon(Icons.Default.PlayArrow, "تشغيل", tint = GoldPrimary, modifier = Modifier.padding(12.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun StudioTransport(playhead: Float, totalDuration: Float, isPlaying: Boolean, onPlay: () -> Unit, onSeek: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(formatTime(playhead), color = GoldPrimary, fontFamily = NotoSansFont, fontSize = 11.sp)
            Slider(value = playhead, onValueChange = onSeek, valueRange = 0f..totalDuration, modifier = Modifier.weight(1f), colors = SliderDefaults.colors(thumbColor = GoldPrimary, activeTrackColor = GoldPrimary))
            Text(formatTime(totalDuration), color = TextSecondary, fontFamily = NotoSansFont, fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            FilledIconButton(onClick = onPlay, colors = IconButtonDefaults.filledIconButtonColors(containerColor = GoldPrimary, contentColor = DeepSlate), modifier = Modifier.size(40.dp)) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null)
            }
        }
    }
}

@Composable
private fun Timeline(
    scenes: List<Scene>,
    selectedIndex: Int,
    playhead: Float,
    onSelect: (Int) -> Unit,
    onSeek: (Float) -> Unit,
    onDelete: (Int) -> Unit,
    onDuplicate: (Int) -> Unit,
    onMove: (Int, Int) -> Unit
) {
    val scroll = rememberScrollState()
    val total = scenes.sumOf { it.durationInSeconds.coerceAtLeast(1) }.toFloat().coerceAtLeast(1f)
    Box(Modifier.fillMaxWidth().horizontalScroll(scroll).height(112.dp)) {
        val widthPerSecond = 72.dp
        Row(Modifier.padding(horizontal = 10.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            scenes.forEachIndexed { index, scene ->
                val selected = index == selectedIndex
                val width = (scene.durationInSeconds.coerceAtLeast(1) * 72).dp
                Surface(modifier = Modifier.width(width).fillMaxHeight().clickable { onSelect(index) }, shape = RoundedCornerShape(10.dp), color = if (selected) Color(0xFF172235) else CardSurface, border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) GoldPrimary else Color(0xFF253247))) {
                    Column(Modifier.padding(7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${index + 1}", color = GoldPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { if (index > 0) onMove(index, index - 1) }, modifier = Modifier.size(20.dp)) { Icon(Icons.Default.ChevronLeft, "تحريك", tint = if (index > 0) TextSecondary else TextSecondary.copy(alpha = 0.25f), modifier = Modifier.size(13.dp)) }
                            IconButton(onClick = { onDuplicate(index) }, modifier = Modifier.size(20.dp)) { Icon(Icons.Default.ContentCopy, "نسخ", tint = TextSecondary, modifier = Modifier.size(13.dp)) }
                            IconButton(onClick = { onDelete(index) }, modifier = Modifier.size(20.dp)) { Icon(Icons.Default.Close, "حذف", tint = TextSecondary, modifier = Modifier.size(13.dp)) }
                        }
                        Text(scene.title, color = TextPrimary, fontFamily = CairoFont, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                        Spacer(Modifier.height(4.dp))
                        Text("${scene.durationInSeconds}s · ${scene.transitionType}", color = TextSecondary, fontSize = 9.sp)
                    }
                }
            }
        }
        val px = (playhead / total) * maxOf(0f, (scenes.sumOf { (it.durationInSeconds.coerceAtLeast(1) * 72) } + (scenes.size - 1) * 6 - 20).toFloat())
        Canvas(Modifier.fillMaxSize().padding(start = (10 + px).dp)) {
            drawLine(GoldPrimary, androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Offset(0f, size.height), strokeWidth = 2.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(7f, 5f)))
        }
    }
}
