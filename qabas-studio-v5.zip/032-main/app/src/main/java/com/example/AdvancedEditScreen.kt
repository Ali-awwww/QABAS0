package com.example

import androidx.compose.runtime.Composable

/**
 * Compatibility entry point for the navigation graph.
 * The actual editor is now StudioWorkspaceScreen.
 */
@Composable
fun AdvancedEditScreen(
    scenes: List<Scene>,
    onUpdateScenes: (List<Scene>) -> Unit,
    onBack: () -> Unit,
    onRender: () -> Unit = {}
) {
    StudioWorkspaceScreen(
        scenes = scenes,
        projectTitle = "استوديو قبس",
        initialRatio = "9:16",
        onUpdateScenes = onUpdateScenes,
        onBack = onBack,
        onRender = onRender
    )
}
