package com.example

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.widget.Toast
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ApiKeysBackupManager {
    fun generateExportJson(
        prefs: SharedPreferences,
        currentKeys: Map<String, String>
    ): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("appName", "Qabas")
        root.put("exportedAt", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
        
        val keysObj = JSONObject()
        val allKeysToExport = listOf(
            "gemini_key",
            "groq_key",
            "pexels_key",
            "pixabay_key",
            "huggingface_key",
            "firebase_key",
            "firebase_project_id",
            "firebase_app_id"
        )
        
        for (k in allKeysToExport) {
            val v = currentKeys[k] ?: prefs.getString(k, "") ?: ""
            if (v.isNotBlank()) {
                keysObj.put(k, v.trim())
            }
        }
        
        root.put("keys", keysObj)
        return root.toString(4)
    }

    fun parseAndApplyImport(
        rawContent: String,
        prefs: SharedPreferences
    ): Pair<Int, Map<String, String>> {
        val importedMap = mutableMapOf<String, String>()
        
        try {
            val trimmed = rawContent.trim()
            if (trimmed.startsWith("{")) {
                val json = JSONObject(trimmed)
                val targetObj = if (json.has("keys")) json.optJSONObject("keys") ?: json else json
                
                val keyMappings = mapOf(
                    "gemini" to "gemini_key",
                    "gemini_key" to "gemini_key",
                    "gemini_api_key" to "gemini_key",
                    "geminikey" to "gemini_key",
                    
                    "groq" to "groq_key",
                    "groq_key" to "groq_key",
                    "groq_api_key" to "groq_key",
                    "groqkey" to "groq_key",
                    
                    "azure" to "azure_speech_key",
                    "azure_speech" to "azure_speech_key",
                    "azure_speech_key" to "azure_speech_key",
                    "azure_key" to "azure_speech_key",
                    "azurespeechkey" to "azure_speech_key",
                    
                    "azure_speech_region" to "azure_speech_region",
                    "azure_region" to "azure_speech_region",
                    "azureregion" to "azure_speech_region",
                    "region" to "azure_speech_region",
                    
                    "elevenlabs" to "elevenlabs_key",
                    "elevenlabs_key" to "elevenlabs_key",
                    "eleven_key" to "elevenlabs_key",
                    "elevenlabskey" to "elevenlabs_key",
                    
                    "pexels" to "pexels_key",
                    "pexels_key" to "pexels_key",
                    "pexels_api_key" to "pexels_key",
                    "pexelskey" to "pexels_key",
                    
                    "pixabay" to "pixabay_key",
                    "pixabay_key" to "pixabay_key",
                    "pixabay_api_key" to "pixabay_key",
                    "pixabaykey" to "pixabay_key",
                    
                    "huggingface" to "huggingface_key",
                    "huggingface_key" to "huggingface_key",
                    "hf_key" to "huggingface_key",
                    "hf_token" to "huggingface_key",
                    "huggingfacekey" to "huggingface_key",
                    
                    "firebase" to "firebase_key",
                    "firebase_key" to "firebase_key",
                    "firebasekey" to "firebase_key",
                    "firebase_project_id" to "firebase_project_id",
                    "firebase_app_id" to "firebase_app_id"
                )
                
                val keysIterator = targetObj.keys()
                while (keysIterator.hasNext()) {
                    val rawKey = keysIterator.next()
                    val normalizedKey = rawKey.lowercase().trim()
                    val prefKey = keyMappings[normalizedKey] ?: if (keyMappings.values.contains(normalizedKey)) normalizedKey else null
                    
                    val value = targetObj.optString(rawKey, "").trim()
                    if (prefKey != null && value.isNotBlank()) {
                        importedMap[prefKey] = value
                    }
                }
            }
        } catch (e: Exception) {
            // If JSON fails, fallback will handle raw text/env
        }

        // If JSON didn't yield anything or failed, parse via line-by-line / regex
        if (importedMap.isEmpty()) {
            val lines = rawContent.lines()
            for (line in lines) {
                val trimmed = line.trim()
                if (trimmed.isBlank() || trimmed.startsWith("#") || trimmed.startsWith("//")) continue
                val cleanLine = trimmed.replace(Regex("""^(val|var|const|let|String|final|static|\"|\')\s*"""), "")
                val parts = cleanLine.split("=", ":", limit = 2)
                if (parts.size == 2) {
                    val keyName = parts[0].trim().lowercase().removeSurrounding("\"", "'")
                    val valStr = parts[1].trim().removeSurrounding("\"", "'").removeSuffix(";").removeSuffix(",")
                    if (valStr.isNotBlank()) {
                        when {
                            keyName.contains("gemini") -> importedMap["gemini_key"] = valStr
                            keyName.contains("groq") -> importedMap["groq_key"] = valStr
                            keyName.contains("azure_region") || (keyName.contains("region") && !keyName.contains("speech")) -> importedMap["azure_speech_region"] = valStr
                            keyName.contains("azure") || keyName.contains("speech") -> importedMap["azure_speech_key"] = valStr
                            keyName.contains("eleven") -> importedMap["elevenlabs_key"] = valStr
                            keyName.contains("pexels") -> importedMap["pexels_key"] = valStr
                            keyName.contains("pixabay") -> importedMap["pixabay_key"] = valStr
                            keyName.contains("hugging") || keyName.contains("hf") -> importedMap["huggingface_key"] = valStr
                            keyName.contains("firebase_project") -> importedMap["firebase_project_id"] = valStr
                            keyName.contains("firebase") -> importedMap["firebase_key"] = valStr
                        }
                    }
                }
            }
            
            // Regex matchers as fallback
            val geminiMatch = Regex("""AIzaSy[A-Za-z0-9_-]{33}""").find(rawContent)?.value
            if (geminiMatch != null && !importedMap.containsKey("gemini_key")) {
                importedMap["gemini_key"] = geminiMatch
            }
            val groqMatch = Regex("""gsk_[A-Za-z0-9]{40,}""").find(rawContent)?.value
            if (groqMatch != null && !importedMap.containsKey("groq_key")) {
                importedMap["groq_key"] = groqMatch
            }
            val hfMatch = Regex("""hf_[A-Za-z0-9]{34,36}""").find(rawContent)?.value
            if (hfMatch != null && !importedMap.containsKey("huggingface_key")) {
                importedMap["huggingface_key"] = hfMatch
            }
            val pixabayMatch = Regex("""[0-9]{8}-[a-f0-9]{24}""").find(rawContent)?.value
            if (pixabayMatch != null && !importedMap.containsKey("pixabay_key")) {
                importedMap["pixabay_key"] = pixabayMatch
            }
            val pexelsMatch = Regex("""[a-zA-Z0-9]{56}""").find(rawContent)?.value
            if (pexelsMatch != null && !importedMap.containsKey("pexels_key") && pexelsMatch != geminiMatch && pexelsMatch != groqMatch) {
                importedMap["pexels_key"] = pexelsMatch
            }
        }

        if (importedMap.isNotEmpty()) {
            val editor = prefs.edit()
            importedMap.forEach { (k, v) ->
                editor.putString(k, v.trim())
            }
            editor.apply()
        }

        return Pair(importedMap.size, importedMap)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiKeysScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("qabas_prefs", Context.MODE_PRIVATE)
    
    var geminiKey by remember { mutableStateOf(SecureSecretStore.get(context, "gemini_key")) }
    var pexelsKey by remember { mutableStateOf(SecureSecretStore.get(context, "pexels_key")) }
    var pixabayKey by remember { mutableStateOf(SecureSecretStore.get(context, "pixabay_key")) }
    var huggingfaceKey by remember { mutableStateOf(SecureSecretStore.get(context, "huggingface_key")) }
    var groqKey by remember { mutableStateOf(SecureSecretStore.get(context, "groq_key")) }
    var firebaseKey by remember { mutableStateOf(SecureSecretStore.get(context, "firebase_key")) }
    
    var saveMessage by remember { mutableStateOf("") }
    var isSavingAndValidating by remember { mutableStateOf(false) }
    var showSmartPasteDialog by remember { mutableStateOf(false) }
    var smartPasteText by remember { mutableStateOf("") }
    var showExportOptionsDialog by remember { mutableStateOf(false) }

    fun syncUiWithPrefs(imported: Map<String, String>) {
        imported["gemini_key"]?.let { geminiKey = it }
        imported["groq_key"]?.let { groqKey = it }
        imported["pexels_key"]?.let { pexelsKey = it }
        imported["pixabay_key"]?.let { pixabayKey = it }
        imported["huggingface_key"]?.let { huggingfaceKey = it }
        imported["firebase_key"]?.let { firebaseKey = it }
    }

    val currentKeysMap = remember(geminiKey, groqKey, pexelsKey, pixabayKey, huggingfaceKey, firebaseKey) {
        mapOf(
            "gemini_key" to geminiKey,
            "groq_key" to groqKey,
            "pexels_key" to pexelsKey,
            "pixabay_key" to pixabayKey,
            "huggingface_key" to huggingfaceKey,
            "firebase_key" to firebaseKey
        )
    }

    // Export JSON Launcher (SAF Save Dialog)
    val exportJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val jsonString = ApiKeysBackupManager.generateExportJson(prefs, currentKeysMap)
                context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                    outputStream.write(jsonString.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(context, "تم تصدير المفاتيح بنجاح إلى ملف JSON 📁✨", Toast.LENGTH_LONG).show()
                SystemLogsManager.addLog("SUCCESS", "تم تصدير ملف مفاتيح API بصيغة JSON بنجاح", Color(0xFF10B981))
            } catch (e: Exception) {
                Toast.makeText(context, "فشل تصدير الملف: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Import JSON / File Launcher
    val importJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val fileContent = inputStream?.bufferedReader()?.use { it.readText() } ?: ""
                if (fileContent.isNotBlank()) {
                    val (count, map) = ApiKeysBackupManager.parseAndApplyImport(fileContent, prefs)
                    if (count > 0) {
                        syncUiWithPrefs(map)
                        Toast.makeText(context, "تم استيراد $count مفاتيح بنجاح من الملف! 📥✨", Toast.LENGTH_LONG).show()
                        SystemLogsManager.addLog("SUCCESS", "تم استيراد $count مفاتيح من ملف JSON وتحديثها", Color(0xFF10B981))
                    } else {
                        Toast.makeText(context, "لم يتم العثور على مفاتيح صالحة داخل الملف", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(context, "الملف المحدد فارغ", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "خطأ في قراءة ملف المفاتيح: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun shareExportJson() {
        try {
            val jsonString = ApiKeysBackupManager.generateExportJson(prefs, currentKeysMap)
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, jsonString)
                putExtra(Intent.EXTRA_TITLE, "نسخة احتياطية لمفاتيح تطبيق قبس (qabas_api_keys.json)")
                type = "text/plain"
            }
            val shareIntent = Intent.createChooser(sendIntent, "مشاركة / حفظ مفاتيح قبس")
            context.startActivity(shareIntent)
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر مشاركة المفاتيح: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    val readinessReport = remember(currentKeysMap) {
        OperationalReadinessManager.calculateReadiness(context, currentKeysMap)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(Translator.tr("مفاتيح واجهة البرمجة (API Keys)"), fontFamily = CairoFont, fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 20.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { exportJsonLauncher.launch("qabas_api_keys.json") }) {
                        Icon(Icons.Default.FileDownload, contentDescription = "تصدير المفاتيح", tint = GoldPrimary)
                    }
                    IconButton(onClick = { importJsonLauncher.launch("*/*") }) {
                        Icon(Icons.Default.FileUpload, contentDescription = "استيراد المفاتيح", tint = GoldSecondary)
                    }
                    IconButton(onClick = { shareExportJson() }) {
                        Icon(Icons.Default.Share, contentDescription = "مشاركة المفاتيح", tint = TextSecondary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepSlate)
            )
        },
        containerColor = DeepSlate
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    // Operational Readiness Percentage Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF151B2B)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "نسبة جاهزية تشغيل التطبيق الحقيقية",
                                        color = TextSecondary,
                                        fontFamily = CairoFont,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = readinessReport.statusTitle,
                                        color = GoldPrimary,
                                        fontSize = 17.sp,
                                        fontFamily = CairoFont,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Surface(
                                    color = GoldPrimary.copy(alpha = 0.15f),
                                    shape = CircleShape,
                                    border = androidx.compose.foundation.BorderStroke(2.dp, GoldPrimary)
                                ) {
                                    Box(
                                        modifier = Modifier.size(64.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${readinessReport.percentage}%",
                                            color = GoldPrimary,
                                            fontFamily = CairoFont,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 20.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Progress Bar
                            LinearProgressIndicator(
                                progress = { readinessReport.percentage / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(5.dp)),
                                color = when {
                                    readinessReport.percentage >= 80 -> Color(0xFF10B981)
                                    readinessReport.percentage >= 35 -> GoldPrimary
                                    else -> Color(0xFFF5D76E)
                                },
                                trackColor = Color(0xFF0B0F19)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = readinessReport.statusDescription,
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontFamily = CairoFont,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(14.dp))
                            HorizontalDivider(color = Color(0xFF1E293B))
                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "تأثير المفاتيح على النسبة الحقيقية للتشغيل:",
                                color = TextSecondary,
                                fontFamily = CairoFont,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                readinessReport.services.forEach { service ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (service.isConfigured) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                                contentDescription = null,
                                                tint = if (service.isConfigured) Color(0xFF10B981) else Color.Gray,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "${service.name} (+${service.weight}%)",
                                                color = if (service.isConfigured) Color.White else Color.Gray,
                                                fontFamily = CairoFont,
                                                fontSize = 11.sp,
                                                fontWeight = if (service.isConfigured) FontWeight.Bold else FontWeight.Normal
                                            )
                                        }
                                        Text(
                                            text = if (service.isConfigured) "حقيقي 🟢" else "محاكاة محلي 🟡",
                                            color = if (service.isConfigured) Color(0xFF10B981) else Color(0xFFF5D76E),
                                            fontFamily = CairoFont,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            if (!readinessReport.lastError.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Surface(
                                    color = Color(0xFFEF4444).copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(8.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.4f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "آخر تقرير خطأ: ${readinessReport.lastError}",
                                            color = Color(0xFFFCA5A5),
                                            fontFamily = CairoFont,
                                            fontSize = 11.sp,
                                            lineHeight = 16.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Dedicated Backup & Import / Export Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B0F19)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = GoldPrimary.copy(alpha = 0.2f),
                                    shape = CircleShape,
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Backup, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(22.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "النسخ الاحتياطي والمزامنة السريعة (JSON) ⚡",
                                        color = GoldPrimary,
                                        fontFamily = CairoFont,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = "تصدير واستيراد جميع مفاتيحك بضغطة زر دون الحاجة لإعادة كتابتها.",
                                        color = TextSecondary,
                                        fontFamily = CairoFont,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // First Row: Export & Import JSON
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { exportJsonLauncher.launch("qabas_api_keys.json") },
                                    modifier = Modifier.weight(1f).height(46.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.FileDownload, contentDescription = null, tint = DeepSlate, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تصدير JSON 📤", color = DeepSlate, fontFamily = CairoFont, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                Button(
                                    onClick = { importJsonLauncher.launch("*/*") },
                                    modifier = Modifier.weight(1f).height(46.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF151B2B)),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.FileUpload, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("استيراد JSON 📥", color = GoldPrimary, fontFamily = CairoFont, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Second Row: Smart Paste & Share
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { showSmartPasteDialog = true },
                                    modifier = Modifier.weight(1f).height(42.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A3A4F)),
                                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color(0xFF141C27)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = GoldSecondary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("اللصق الذكي 📋", color = GoldSecondary, fontFamily = CairoFont, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { shareExportJson() },
                                    modifier = Modifier.weight(1f).height(42.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A3A4F)),
                                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color(0xFF141C27)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("مشاركة المفاتيح 🔗", color = TextSecondary, fontFamily = CairoFont, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                item {
                    ApiKeyCard(
                        serviceType = "gemini",
                        title = "1. Gemini API (Google AI)",
                        description = Translator.tr("النموذج الأذكى لصياغة السكريبتات الدعوية والمساعد الإسلامي الذكي وقصص الأنبياء."),
                        url = "https://aistudio.google.com/app/apikey",
                        instructions = "1. قم بتسجيل الدخول إلى Google AI Studio.\n2. اضغط على زر 'Create API Key' (إنشاء مفتاح).\n3. انسخ المفتاح والصقه هنا.",
                        icon = Icons.Default.AutoAwesome,
                        value = geminiKey,
                        onValueChange = { geminiKey = it }
                    )
                }

                item {
                    ApiKeyCard(
                        serviceType = "groq",
                        title = "2. Groq API / xAI Grok",
                        description = Translator.tr("معالجة فائقة السرعة للنصوص وتوليد الأفكار الفورية للريلز (يدعم Groq Cloud المجاني أو xAI Grok)."),
                        url = "https://console.groq.com/keys",
                        instructions = "• الخيار المجاني الموصى به (Groq):\n1. ادخل إلى console.groq.com/keys\n2. أنشئ حساباً مجانياً وانسخ المفتاح (يبدأ بـ gsk_).\n\n• خيار xAI Grok:\nإذا كنت تستخدم مفتاح x.ai (يبدأ بـ xai-)، تأكد من توفر رصيد نشط في console.x.ai.",
                        icon = Icons.Default.Speed,
                        value = groqKey,
                        onValueChange = { groqKey = it }
                    )
                }
                
                item {
                    ApiKeyCard(
                        serviceType = "huggingface",
                        title = "3. Hugging Face Token",
                        description = Translator.tr("توليد الصور الإسلامية والخلفيات البصرية بالذكاء الاصطناعي مجاناً."),
                        url = "https://huggingface.co/settings/tokens",
                        instructions = "1. ادخل لموقع HuggingFace وأنشيء حساب.\n2. اذهب إلى الإعدادات ثم Access Tokens.\n3. أنشئ Token جديد بصلاحية 'Read'.",
                        icon = Icons.Default.Memory,
                        value = huggingfaceKey,
                        onValueChange = { huggingfaceKey = it }
                    )
                }

                item {
                    ApiKeyCard(
                        serviceType = "pexels",
                        title = "4. Pexels API Key",
                        description = Translator.tr("مكتبة الفيديوهات والصور المجانية عالية الجودة (طبيعة، مساجد، ومعالم إسلامية)."),
                        url = "https://www.pexels.com/api/",
                        instructions = "1. سجل دخولك في موقع Pexels.\n2. اذهب إلى Image & Video API.\n3. قم بتقديم طلب للحصول على مفتاح.",
                        icon = Icons.Default.VideoLibrary,
                        value = pexelsKey,
                        onValueChange = { pexelsKey = it }
                    )
                }

                item {
                    ApiKeyCard(
                        serviceType = "pixabay",
                        title = "5. Pixabay API Key",
                        description = Translator.tr("مؤثرات بصرية وصوتية إضافية خالية من حقوق الطبع والنشر للمونتاج."),
                        url = "https://pixabay.com/api/docs/",
                        instructions = "1. سجل دخولك في Pixabay.\n2. اذهب لأسفل الصفحة واضغط على API.\n3. ستجد مفتاحك في قسم 'Search Images'.",
                        icon = Icons.Default.Image,
                        value = pixabayKey,
                        onValueChange = { pixabayKey = it }
                    )
                }

                item {
                    FirebaseConfigCard(
                        value = firebaseKey,
                        onValueChange = { firebaseKey = it }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepSlate)
                    .padding(16.dp)
            ) {
                Column {
                    if (saveMessage.isNotEmpty()) {
                        Text(
                            text = saveMessage,
                            color = GoldPrimary,
                            fontFamily = CairoFont,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 12.dp)
                        )
                    }
                    Button(
                        onClick = {
                            SecureSecretStore.put(context, "gemini_key", geminiKey.trim())
                            SecureSecretStore.put(context, "groq_key", groqKey.trim())
                            SecureSecretStore.put(context, "pexels_key", pexelsKey.trim())
                            SecureSecretStore.put(context, "pixabay_key", pixabayKey.trim())
                            SecureSecretStore.put(context, "huggingface_key", huggingfaceKey.trim())
                            SecureSecretStore.put(context, "firebase_key", firebaseKey.trim())
                            saveMessage = Translator.tr("تم حفظ وتحديث جميع المفاتيح بنجاح! ✨")
                            SystemLogsManager.addLog("INFO", "تم حفظ إعدادات المفاتيح في ذاكرة التطبيق بنجاح", Color(0xFF10B981))
                            Toast.makeText(context, Translator.tr("تم حفظ المفاتيح بنجاح! الأنظمة جاهزة للعمل 🚀"), Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.VpnKey, contentDescription = null, tint = DeepSlate, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(Translator.tr("حفظ وتحديث المفاتيح"), color = DeepSlate, fontFamily = TajawalFont, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
            }
        }
    }

    if (showSmartPasteDialog) {
        AlertDialog(
            onDismissRequest = { showSmartPasteDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = GoldPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("اللصق الذكي والتوزيع التلقائي", fontFamily = TajawalFont, fontWeight = FontWeight.Bold, color = GoldPrimary, fontSize = 16.sp)
                }
            },
            text = {
                Column {
                    Text(
                        "الصق هنا أي نص أو كود JSON أو ملف .env، وسيتم التعرف على المفاتيح وتوزيعها تلقائياً على كافة الحقول!",
                        fontFamily = CairoFont,
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = smartPasteText,
                        onValueChange = { smartPasteText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        placeholder = { Text("الصق النص أو ملف JSON هنا...\nمثال:\nGEMINI_KEY=AIzaSy...\nأو كود JSON", color = Color.Gray, fontSize = 12.sp, fontFamily = NotoSansFont) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = Color(0xFF1E293B),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = GoldPrimary,
                            focusedContainerColor = Color(0xFF141C27),
                            unfocusedContainerColor = Color(0xFF141C27)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (smartPasteText.isNotBlank()) {
                            val (count, map) = ApiKeysBackupManager.parseAndApplyImport(smartPasteText, prefs)
                            if (count > 0) {
                                syncUiWithPrefs(map)
                                Toast.makeText(context, "تم التعرف على $count مفاتيح وتوزيعها بنجاح! 🎉", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "لم يتم العثور على أي مفاتيح معروفة في النص المنسوخ", Toast.LENGTH_SHORT).show()
                            }
                            smartPasteText = ""
                            showSmartPasteDialog = false
                        } else {
                            Toast.makeText(context, "يرجى لصق النص أولاً", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                ) {
                    Text("استخراج وتوزيع المفاتيح تلقائياً ⚡", color = DeepSlate, fontFamily = CairoFont, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSmartPasteDialog = false }) {
                    Text("إلغاء", color = TextSecondary, fontFamily = CairoFont)
                }
            },
            containerColor = Color(0xFF151B2B)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiKeyCard(
    serviceType: String,
    title: String,
    description: String,
    url: String,
    instructions: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String,
    onValueChange: (String) -> Unit,
    secondaryFieldLabel: String? = null,
    secondaryValue: String? = null,
    onSecondaryValueChange: ((String) -> Unit)? = null
) {
    val context = LocalContext.current
    var isKeyVisible by remember { mutableStateOf(false) }
    var showInstructions by remember { mutableStateOf(false) }

    var validationStatus by remember { mutableStateOf<KeyValidationStatus>(KeyValidationStatus.Idle) }
    val scope = rememberCoroutineScope()

    var showDiagnosticsDialog by remember { mutableStateOf(false) }

    // Auto test on initial load if key exists
    LaunchedEffect(value) {
        if (value.isNotBlank() && validationStatus is KeyValidationStatus.Idle) {
            validationStatus = KeyValidationStatus.Testing
            val res = ApiKeyValidator.validateKey(serviceType, value)
            validationStatus = if (res.isValid) KeyValidationStatus.Valid(res) else KeyValidationStatus.Invalid(res)
        } else if (value.isBlank()) {
            validationStatus = KeyValidationStatus.Idle
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            when (validationStatus) {
                is KeyValidationStatus.Valid -> Color(0xFF4CAF50)
                is KeyValidationStatus.Invalid -> Color(0xFFEF4444)
                KeyValidationStatus.Testing -> GoldPrimary
                else -> Color(0xFF1E293B)
            }
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(GoldPrimary.copy(alpha = 0.1f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(22.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(title, color = Color.White, fontFamily = TajawalFont, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val (statusText, statusColor) = when (val s = validationStatus) {
                                is KeyValidationStatus.Valid -> Pair(s.result.summary, Color(0xFF4CAF50))
                                is KeyValidationStatus.Invalid -> Pair(s.result.summary, Color(0xFFEF4444))
                                KeyValidationStatus.Testing -> Pair("جاري الفحص الفعلي...", GoldPrimary)
                                KeyValidationStatus.Idle -> if (value.isNotBlank()) Pair("مفعل 🟢", Color(0xFF4CAF50)) else Pair("غير محدد (اختياري) 🟡", Color.Gray)
                            }
                            Text(
                                text = statusText,
                                color = statusColor,
                                fontFamily = CairoFont,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
                
                IconButton(
                    onClick = { showInstructions = true },
                    modifier = Modifier.background(Color(0xFF2A3A4F), CircleShape).size(36.dp)
                ) {
                    Icon(Icons.Default.Info, contentDescription = "كيفية الحصول عليه", tint = GoldPrimary, modifier = Modifier.size(20.dp))
                }
            }
            
            if (showInstructions) {
                AlertDialog(
                    onDismissRequest = { showInstructions = false },
                    containerColor = CardSurface,
                    title = {
                        Text(Translator.tr("طريقة الحصول على المفتاح"), color = GoldPrimary, fontFamily = TajawalFont, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    },
                    text = {
                        Column {
                            Text(instructions, color = Color.White, fontFamily = NotoSansFont, fontSize = 14.sp, lineHeight = 22.sp)
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showInstructions = false
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, Translator.tr("تعذر فتح الرابط"), Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                        ) {
                            Text(Translator.tr("فتح الموقع"), color = DeepSlate, fontFamily = CairoFont, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showInstructions = false }) {
                            Text(Translator.tr("إغلاق"), color = TextSecondary, fontFamily = CairoFont)
                        }
                    }
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            Text(description, color = TextSecondary, fontFamily = NotoSansFont, fontSize = 14.sp, lineHeight = 20.sp)
            Spacer(modifier = Modifier.height(14.dp))
            
            OutlinedTextField(
                value = value,
                onValueChange = {
                    onValueChange(it)
                    validationStatus = KeyValidationStatus.Idle
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(Translator.tr("الصق المفتاح هنا..."), color = Color.Gray, fontFamily = NotoSansFont, fontSize = 14.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = Color(0xFF1E293B),
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = GoldPrimary,
                    focusedContainerColor = Color(0xFF141C27),
                    unfocusedContainerColor = Color(0xFF141C27)
                ),
                visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { isKeyVisible = !isKeyVisible }) {
                            Icon(
                                imageVector = if (isKeyVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "رؤية المفتاح",
                                tint = GoldPrimary
                            )
                        }
                        if (value.isNotBlank()) {
                            Icon(
                                imageVector = when (validationStatus) {
                                    is KeyValidationStatus.Valid -> Icons.Default.CheckCircle
                                    is KeyValidationStatus.Invalid -> Icons.Default.Error
                                    else -> Icons.Default.CheckCircle
                                },
                                contentDescription = null,
                                tint = when (validationStatus) {
                                    is KeyValidationStatus.Valid -> Color(0xFF4CAF50)
                                    is KeyValidationStatus.Invalid -> Color(0xFFEF4444)
                                    else -> Color(0xFF4CAF50)
                                },
                                modifier = Modifier.size(20.dp).padding(end = 6.dp)
                            )
                        }
                    }
                }
            )

            // Optional secondary field (e.g. Region)
            if (secondaryFieldLabel != null && secondaryValue != null && onSecondaryValueChange != null) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = secondaryValue,
                    onValueChange = onSecondaryValueChange,
                    label = { Text(secondaryFieldLabel, color = Color.Gray, fontFamily = CairoFont, fontSize = 12.sp) },
                    placeholder = { Text("مثال: eastus أو westeurope", color = Color.DarkGray, fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = Color(0xFF1E293B),
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = Color(0xFF141C27),
                        unfocusedContainerColor = Color(0xFF141C27)
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // Dynamic detail box showing connection result
            when (val status = validationStatus) {
                is KeyValidationStatus.Valid -> {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = Color(0xFF10B981).copy(alpha = 0.12f),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(status.result.summary, color = Color(0xFF10B981), fontFamily = CairoFont, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(status.result.explanation, color = TextPrimary, fontFamily = NotoSansFont, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                }
                is KeyValidationStatus.Invalid -> {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = Color(0xFFEF4444).copy(alpha = 0.12f),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.Error, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(status.result.summary, color = Color(0xFFEF4444), fontFamily = CairoFont, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { showDiagnosticsDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Icon(Icons.Default.HelpOutline, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("لماذا تم الرفض؟", color = Color.White, fontFamily = CairoFont, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(status.result.explanation, color = TextPrimary, fontFamily = NotoSansFont, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                }
                KeyValidationStatus.Testing -> {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(color = GoldPrimary, modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("جاري الاتصال بالسيرفر الحقيقي واختبار الاستجابة الآن...", color = GoldPrimary, fontFamily = NotoSansFont, fontSize = 12.sp)
                    }
                }
                KeyValidationStatus.Idle -> {}
            }

            if (value.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                validationStatus = KeyValidationStatus.Testing
                                val res = ApiKeyValidator.validateKey(serviceType, value)
                                validationStatus = if (res.isValid) KeyValidationStatus.Valid(res) else KeyValidationStatus.Invalid(res)
                            }
                        },
                        modifier = Modifier.weight(1f).height(38.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("فحص الاتصال الفعلي ⚡", color = GoldPrimary, fontFamily = CairoFont, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    if (validationStatus is KeyValidationStatus.Invalid || validationStatus is KeyValidationStatus.Valid) {
                        OutlinedButton(
                            onClick = { showDiagnosticsDialog = true },
                            modifier = Modifier.height(38.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.FindInPage, contentDescription = null, tint = GoldSecondary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("سبب الحالة 🔍", color = GoldSecondary, fontFamily = CairoFont, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Dialog for diagnostics
            if (showDiagnosticsDialog) {
                val currentResult = when (val s = validationStatus) {
                    is KeyValidationStatus.Valid -> s.result
                    is KeyValidationStatus.Invalid -> s.result
                    else -> null
                }

                AlertDialog(
                    onDismissRequest = { showDiagnosticsDialog = false },
                    containerColor = CardSurface,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (currentResult?.isValid == true) Icons.Default.CheckCircle else Icons.Default.BugReport,
                                contentDescription = null,
                                tint = if (currentResult?.isValid == true) Color(0xFF10B981) else Color(0xFFEF4444),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (currentResult?.isValid == true) "تقرير تشغيل المفتاح الفعلي ✅" else "تشخيص سبب رفض المفتاح 🔍",
                                color = GoldPrimary,
                                fontFamily = TajawalFont,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                        }
                    },
                    text = {
                        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                            if (currentResult != null) {
                                if (currentResult.errorCode != null) {
                                    Surface(
                                        color = Color(0xFF0B0F19),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("رمز الاستجابة (HTTP Code):", color = TextSecondary, fontFamily = CairoFont, fontSize = 12.sp)
                                            Text(
                                                text = "${currentResult.errorCode}",
                                                color = if (currentResult.isValid) Color(0xFF10B981) else Color(0xFFEF4444),
                                                fontFamily = CairoFont,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = "السبب والتحليل الفني:",
                                    color = GoldPrimary,
                                    fontFamily = CairoFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentResult.explanation.ifBlank { "لا توجد تفاصيل إضافية." },
                                    color = Color.White,
                                    fontFamily = NotoSansFont,
                                    fontSize = 13.sp,
                                    lineHeight = 20.sp
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                Text(
                                    text = "الحل والخطوة القادمة المقترحة:",
                                    color = Color(0xFF10B981),
                                    fontFamily = CairoFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentResult.suggestedFix.ifBlank { "تأكد من صحة المفتاح." },
                                    color = TextSecondary,
                                    fontFamily = NotoSansFont,
                                    fontSize = 13.sp,
                                    lineHeight = 20.sp
                                )

                                if (!currentResult.rawError.isNullOrBlank()) {
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text(
                                        text = "الرد المباشر من السيرفر (Raw Response):",
                                        color = TextSecondary,
                                        fontFamily = CairoFont,
                                        fontSize = 11.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Surface(
                                        color = Color(0xFF0B0F19),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = currentResult.rawError ?: "",
                                            color = Color(0xFFEF4444),
                                            fontFamily = NotoSansFont,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(8.dp)
                                        )
                                    }
                                }
                            } else {
                                Text("لم يتم إجراء فحص تشخيصي بعد. اضغط على فحص الاتصال أولاً.", color = Color.White)
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = { showDiagnosticsDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                        ) {
                            Text("فهمت، حسناً", color = DeepSlate, fontFamily = TajawalFont, fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirebaseConfigCard(
    value: String,
    onValueChange: (String) -> Unit
) {
    val context = LocalContext.current
    var showPasteDialog by remember { mutableStateOf(false) }
    var pastedJson by remember { mutableStateOf("") }
    
    val prefs = context.getSharedPreferences("qabas_prefs", Context.MODE_PRIVATE)
    val projectId = prefs.getString("firebase_project_id", "") ?: ""
    val isInitialized = CloudServices.isFirebaseInitialized

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val jsonText = inputStream?.bufferedReader()?.use { it.readText() } ?: ""
                if (jsonText.isNotBlank()) {
                    val (success, msg) = CloudServices.initializeWithJson(context, jsonText)
                    if (success) {
                        val newKey = SecureSecretStore.get(context, "firebase_key")
                        onValueChange(newKey)
                        Toast.makeText(context, Translator.tr("تم إدراج ملف google-services.json وتفعيل خدمات Firebase بنجاح! 🔥"), Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, Translator.tr(msg), Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, Translator.tr("خطأ في قراءة الملف: ") + e.localizedMessage, Toast.LENGTH_SHORT).show()
            }
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isInitialized) GoldPrimary else Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(GoldPrimary.copy(alpha = 0.1f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Cloud, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(22.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("8. Firebase Config (google-services.json)", color = Color.White, fontFamily = TajawalFont, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(
                            text = if (isInitialized) Translator.tr("مربوط بالسحابة 🔥 (${if (projectId.isNotEmpty()) projectId else "نشط"})") else Translator.tr("غير مفعل (اختياري) 🟡"),
                            color = if (isInitialized) Color(0xFF4CAF50) else Color.Gray,
                            fontFamily = CairoFont,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                Translator.tr("حفظ المشاريع سحابياً، ومزامنة بيانات القناة والمشتركين مباشرة مع السيرفر."),
                color = TextSecondary,
                fontFamily = CairoFont,
                fontSize = 13.sp,
                lineHeight = 20.sp
            )
            
            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { filePickerLauncher.launch("application/json") },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.UploadFile, contentDescription = null, tint = DeepSlate, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(Translator.tr("إدراج ملف google-services.json 📁"), color = DeepSlate, fontFamily = CairoFont, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = { showPasteDialog = true },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Code, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(Translator.tr("أو إلصاق كود JSON مباشرة 📋"), color = GoldPrimary, fontFamily = CairoFont)
            }

            if (value.isNotBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(Translator.tr("مفتاح API الخاص بـ Firebase"), color = Color.Gray, fontFamily = NotoSansFont, fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = Color(0xFF1E293B),
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = GoldPrimary,
                        focusedContainerColor = Color(0xFF141C27),
                        unfocusedContainerColor = Color(0xFF141C27)
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    trailingIcon = {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF4CAF50), modifier = Modifier.size(20.dp))
                    }
                )
            }
        }
    }

    if (showPasteDialog) {
        AlertDialog(
            onDismissRequest = { showPasteDialog = false },
            containerColor = CardSurface,
            title = {
                Text(Translator.tr("إلصاق نص google-services.json"), color = GoldPrimary, fontFamily = TajawalFont, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            },
            text = {
                Column {
                    Text(Translator.tr("الصق محتوى ملف google-services.json هنا:"), color = Color.White, fontFamily = NotoSansFont, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pastedJson,
                        onValueChange = { pastedJson = it },
                        modifier = Modifier.fillMaxWidth().height(180.dp),
                        placeholder = { Text("{\n  \"project_info\": ...\n}", color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = Color(0xFF1E293B),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = Color(0xFF141C27),
                            unfocusedContainerColor = Color(0xFF141C27)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPasteDialog = false
                        if (pastedJson.isNotBlank()) {
                            val (success, msg) = CloudServices.initializeWithJson(context, pastedJson)
                            if (success) {
                                val newKey = SecureSecretStore.get(context, "firebase_key")
                                onValueChange(newKey)
                                Toast.makeText(context, Translator.tr("تم تفعيل خدمات Firebase بنجاح! 🔥"), Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, Translator.tr(msg), Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                ) {
                    Text(Translator.tr("حفظ وتفعيل"), color = DeepSlate, fontFamily = CairoFont, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPasteDialog = false }) {
                    Text(Translator.tr("إلغاء"), color = TextSecondary, fontFamily = CairoFont)
                }
            }
        )
    }
}
