package com.example

/**
 * Server-side purchase verification contract.
 * Google Play purchases are verified by BillingManager and, for production-grade
 * entitlement security, should also be verified server-side using the Play Developer API.
 */
object PurchaseValidator {
    suspend fun verifyPurchase(itemId: String, purchaseToken: String): Boolean {
        return false
    }
}
