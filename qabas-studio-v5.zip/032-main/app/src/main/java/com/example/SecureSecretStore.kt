package com.example

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Small Android Keystore-backed secret store for user-provided API credentials.
 * The values remain in app-private SharedPreferences, but their contents are
 * encrypted with a non-exportable AES key held by Android Keystore.
 */
object SecureSecretStore {
    private const val PREFS = "qabas_secure_secrets"
    private const val KEYSTORE = "AndroidKeyStore"
    private const val ALIAS = "qabas_api_secrets_v1"
    private const val PREFIX = "enc:v1:"

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        (keyStore.getKey(ALIAS, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    fun get(context: Context, key: String): String {
        val securePrefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val stored = securePrefs.getString(key, null)
        if (!stored.isNullOrBlank() && stored.startsWith(PREFIX)) {
            return decrypt(stored.removePrefix(PREFIX)) ?: ""
        }

        // One-time migration from the legacy plaintext preferences used by the original project.
        val legacyPrefs = context.getSharedPreferences("qabas_prefs", Context.MODE_PRIVATE)
        val legacy = legacyPrefs.getString(key, "") ?: ""
        if (legacy.isNotBlank()) {
            put(context, key, legacy)
            legacyPrefs.edit().remove(key).apply()
        }
        return legacy
    }

    fun put(context: Context, key: String, value: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (value.isBlank()) {
            prefs.edit().remove(key).apply()
            return
        }
        prefs.edit().putString(key, PREFIX + encrypt(value)).apply()
    }

    fun remove(context: Context, key: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(key).apply()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        val ciphertext = Base64.encodeToString(cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8)), Base64.NO_WRAP)
        return "$iv.$ciphertext"
    }

    private fun decrypt(value: String): String? {
        return try {
            val parts = value.split('.', limit = 2)
            if (parts.size != 2) return null
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val ciphertext = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), StandardCharsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }
}
